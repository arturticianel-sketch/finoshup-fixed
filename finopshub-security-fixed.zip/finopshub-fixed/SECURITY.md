# Security Guide — FinOpsHub

## Environment Variables

Copy `.env.example` to `.env` and fill in all required values before running.

```bash
cp .env.example .env
```

**Never commit `.env` to version control.** It is already in `.gitignore`.

### Generating a strong JWT_SECRET

```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

---

## Dependencies Added (Security)

| Package | Purpose |
|---------|---------|
| `bcrypt` | Secure password hashing (replaces SHA-256) |
| `helmet` | HTTP security headers (CSP, X-Frame-Options, HSTS, etc.) |
| `express-rate-limit` | Brute-force protection on auth endpoints |

Install after cloning:

```bash
pnpm install
```

---

## Production Checklist

- [ ] `JWT_SECRET` set to a random 64+ char string in environment
- [ ] `ALLOWED_ORIGINS` set to your real domain(s)
- [ ] `NODE_ENV=production` 
- [ ] Google OAuth implemented via `google-auth-library` (current mock is dev-only)
- [ ] Database persistence configured (replace in-memory stores with Drizzle/MySQL)
- [ ] HTTPS enabled (required for `secure` cookies)
- [ ] Review and tighten Content-Security-Policy as needed

---

## What Was Fixed

| Issue | Severity | Fix |
|-------|----------|-----|
| `JWT_SECRET` hardcoded | Critical | Moved to `process.env.JWT_SECRET` with startup guard |
| `cors({ origin: "*" })` | Critical | Restricted to `ALLOWED_ORIGINS` env var |
| `sameSite: "none"` always | Critical | Changed to `"lax"`, domain logic restored |
| SHA-256 + fixed salt passwords | High | Replaced with `bcrypt` (12 rounds) |
| No rate limiting on auth | High | `express-rate-limit` on login/register/google |
| No security headers | Medium | `helmet` added |
| tRPC financial routes using `publicProcedure` | High | Changed to `protectedProcedure` |
| NFes/operacoes exposed to all users | Medium | Scoped to authenticated `userId` |
| Card number/CVV hardcoded | Low | Randomly generated per creation |
| `dangerouslySetInnerHTML` unsanitized | Low | CSS values and id sanitized with allowlist |
| Demo seed credentials in source | Info | Removed; users register via `/auth/register` |
