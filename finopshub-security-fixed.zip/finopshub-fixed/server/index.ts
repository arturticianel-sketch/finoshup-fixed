import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import cors from "cors";
import jwt from "jsonwebtoken";
import crypto from "crypto";
import helmet from "helmet";
import rateLimit from "express-rate-limit";
import bcrypt from "bcrypt";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ─── Secrets from environment (NEVER hardcode) ────────────────────────────────
const JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  throw new Error("JWT_SECRET environment variable is required. Set it in your .env file.");
}

const BCRYPT_ROUNDS = 12;

async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}

async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// ─── In-memory stores ─────────────────────────────────────────────────────────
interface User {
  id: string; name: string; email: string;
  passwordHash?: string; provider: "email" | "google"; avatar: string;
}
interface Wallet {
  userId: string; publicKey: string; solBalance: number;
  usdcBalance: number; network: string; isNew?: boolean; createdAt: string;
}
interface VirtualCard {
  id: string; userId: string; number: string; cvv: string; expiry: string;
  holderName: string; balance: number; usdcBalance: number;
  network: string; status: "active" | "blocked"; createdAt: string;
}
interface CardTx {
  id: string; merchant: string; amountBRL: number;
  usdcDeducted: number; date: string; type: "purchase" | "fund";
}
interface NFeRecord {
  id: string; userId: string; numero: string; cliente: string; valor: number;
  vencimento: string; diasVencimento: number; status: "pendente" | "antecipada"; txHash?: string;
}
interface Operacao {
  id: string; userId: string; nfeId: string; nfeNumero: string; cliente: string;
  valorOriginalBRL: number; liquidoBRL: number; custoTotalBRL: number;
  txHash: string; timestamp: string;
}

const users: User[] = [];
const wallets: Record<string, Wallet> = {};
const cards: Record<string, VirtualCard> = {};
const cardTxs: Record<string, CardTx[]> = {};
const nfes: NFeRecord[] = [];
const operacoes: Operacao[] = [];

const now = new Date();
const addDays = (d: Date, n: number) => {
  const r = new Date(d); r.setDate(r.getDate() + n);
  return r.toISOString().split("T")[0];
};

function seedNfesForUser(userId: string) {
  if (nfes.some((n) => n.userId === userId)) return;
  nfes.push(
    { id: `${userId}-nfe-001`, userId, numero: "NF-e 123", cliente: "Tech Solutions Ltda", valor: 85000, vencimento: addDays(now, 55), diasVencimento: 55, status: "pendente" },
    { id: `${userId}-nfe-002`, userId, numero: "NF-e 124", cliente: "Inovação Digital S.A.", valor: 42000, vencimento: addDays(now, 28), diasVencimento: 28, status: "pendente" },
    { id: `${userId}-nfe-003`, userId, numero: "NF-e 125", cliente: "Consultoria RH Brasil", valor: 120000, vencimento: addDays(now, 45), diasVencimento: 45, status: "antecipada", txHash: "demo_hash_already_done" }
  );
  operacoes.push({
    id: `${userId}-op-001`, userId, nfeId: `${userId}-nfe-003`, nfeNumero: "NF-e 125",
    cliente: "Consultoria RH Brasil", valorOriginalBRL: 120000, liquidoBRL: 78120,
    custoTotalBRL: 41880, txHash: "demo_hash_already_done", timestamp: addDays(now, -5),
  });
}

function simulateDeFiProtocol(valorBRL: number, diasVencimento: number) {
  const USD_BRL = 5.0;
  const valorUSDC = valorBRL / USD_BRL;
  const taxaMensal = 0.012; const meses = diasVencimento / 30; const ltvRatio = 0.7;
  const liquidoUSDC = valorUSDC * ltvRatio * (1 - taxaMensal * meses);
  const liquidoBRL = liquidoUSDC * USD_BRL;
  const custoTotal = valorBRL - liquidoBRL;
  return {
    valorOriginalBRL: valorBRL, valorUSDC: +valorUSDC.toFixed(2),
    liquidoUSDC: +liquidoUSDC.toFixed(2), liquidoBRL: +liquidoBRL.toFixed(2),
    custoTotalBRL: +custoTotal.toFixed(2), custoPercent: +((custoTotal / valorBRL) * 100).toFixed(2),
    taxaMensalPercent: 1.2, ltvRatio: 0.7, diasVencimento,
    economiaVsFactoring: +((valorBRL * 0.05 * meses) - custoTotal).toFixed(2),
    protocolo: "Kamino Finance (simulado — devnet)", isMVP: true,
  };
}

async function gravaAuditTrail(payload: object): Promise<string> {
  try {
    const { Connection, Keypair, Transaction, TransactionInstruction, PublicKey, sendAndConfirmTransaction } =
      await import("@solana/web3.js");
    const conn = new Connection("https://api.devnet.solana.com", "confirmed");
    const payer = Keypair.generate();
    const MEMO_PROGRAM = new PublicKey("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr");
    const memo = JSON.stringify({ ...payload, app: "FinOpsHub", v: "1.0.0" });
    const ix = new TransactionInstruction({ programId: MEMO_PROGRAM, keys: [], data: Buffer.from(memo.slice(0, 560), "utf-8") });
    return await sendAndConfirmTransaction(conn, new Transaction().add(ix), [payer]);
  } catch {
    return `OFFLINE_${crypto.randomBytes(16).toString("hex")}`;
  }
}

function authMiddleware(
  req: express.Request & { userId?: string; user?: User },
  res: express.Response, next: express.NextFunction
) {
  const token = req.headers.authorization?.replace("Bearer ", "");
  if (!token) { res.status(401).json({ erro: "Token necessário" }); return; }
  try {
    const decoded = jwt.verify(token, JWT_SECRET!) as { userId: string; email: string };
    req.userId = decoded.userId;
    req.user = users.find((u) => u.id === decoded.userId);
    if (!req.user) { res.status(401).json({ erro: "Usuário não encontrado" }); return; }
    next();
  } catch {
    res.status(401).json({ erro: "Token inválido" });
  }
}

async function startServer() {
  const app = express();

  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'", "https://api.devnet.solana.com"],
      },
    },
  }));

  const allowedOrigins = (process.env.ALLOWED_ORIGINS ?? "http://localhost:3000")
    .split(",").map((o) => o.trim());

  app.use(cors({
    origin: (origin, cb) => {
      if (!origin || allowedOrigins.includes(origin)) cb(null, true);
      else cb(new Error(`CORS: origin ${origin} not allowed`));
    },
    credentials: true,
  }));

  app.use(express.json({ limit: "100kb" }));

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, max: 10,
    message: { erro: "Muitas tentativas. Tente novamente em 15 minutos." },
    standardHeaders: true, legacyHeaders: false,
  });
  const apiLimiter = rateLimit({
    windowMs: 60 * 1000, max: 120,
    standardHeaders: true, legacyHeaders: false,
  });

  app.use("/auth/login", authLimiter);
  app.use("/auth/register", authLimiter);
  app.use("/auth/google", authLimiter);
  app.use("/api/", apiLimiter);

  // ── AUTH ──────────────────────────────────────────────────────────────────

  app.post("/auth/google", (req, res) => {
    if (process.env.NODE_ENV === "production") {
      res.status(501).json({ erro: "Google OAuth não configurado para produção — implemente google-auth-library" });
      return;
    }
    const googleUser: User = { id: "google-1", name: "Lucas Ferreira", email: "lucas@gmail.com", provider: "google", avatar: "LF" };
    const existing = users.find((u) => u.id === "google-1");
    if (!existing) users.push(googleUser);
    const user = existing || googleUser;
    seedNfesForUser(user.id);
    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET!, { expiresIn: "7d" });
    res.json({ token, user: { ...user, passwordHash: undefined } });
  });

  app.post("/auth/login", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password || typeof email !== "string" || typeof password !== "string") {
      res.status(400).json({ erro: "Email e senha obrigatórios" }); return;
    }
    const user = users.find((u) => u.email === email.toLowerCase().trim());
    const dummyHash = "$2b$12$invalidhashpaddingtopreventinenumeration000000000000000";
    const valid = user?.passwordHash
      ? await verifyPassword(password, user.passwordHash)
      : await bcrypt.compare(password, dummyHash).then(() => false);
    if (!valid || !user) { res.status(401).json({ erro: "Email ou senha incorretos" }); return; }
    seedNfesForUser(user.id);
    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET!, { expiresIn: "7d" });
    res.json({ token, user: { ...user, passwordHash: undefined } });
  });

  app.post("/auth/register", async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password || typeof name !== "string" || typeof email !== "string" || typeof password !== "string") {
      res.status(400).json({ erro: "Todos os campos são obrigatórios" }); return;
    }
    if (password.length < 8) { res.status(400).json({ erro: "Senha deve ter no mínimo 8 caracteres" }); return; }
    const normalizedEmail = email.toLowerCase().trim();
    if (users.find((u) => u.email === normalizedEmail)) { res.status(400).json({ erro: "Email já cadastrado" }); return; }
    const newUser: User = {
      id: `user-${crypto.randomUUID()}`, name: name.trim(), email: normalizedEmail,
      passwordHash: await hashPassword(password), provider: "email",
      avatar: name.trim().split(" ").slice(0, 2).map((w: string) => w[0]).join("").toUpperCase(),
    };
    users.push(newUser);
    seedNfesForUser(newUser.id);
    const token = jwt.sign({ userId: newUser.id, email: newUser.email }, JWT_SECRET!, { expiresIn: "7d" });
    res.json({ token, user: { ...newUser, passwordHash: undefined } });
  });

  app.get("/auth/me", authMiddleware as express.RequestHandler, (req: any, res) => {
    res.json({ ...req.user, passwordHash: undefined });
  });

  app.patch("/auth/profile", authMiddleware as express.RequestHandler, (req: any, res) => {
    const { name } = req.body;
    if (name && typeof name === "string") {
      req.user.name = name.trim();
      req.user.avatar = name.trim().split(" ").slice(0, 2).map((w: string) => w[0]).join("").toUpperCase();
    }
    res.json({ ...req.user, passwordHash: undefined });
  });

  app.patch("/auth/password", authMiddleware as express.RequestHandler, async (req: any, res) => {
    const { currentPassword, newPassword } = req.body;
    if (req.user.provider === "google") { res.status(400).json({ erro: "Usuários Google não podem alterar senha" }); return; }
    if (!newPassword || newPassword.length < 8) { res.status(400).json({ erro: "Nova senha deve ter no mínimo 8 caracteres" }); return; }
    if (!await verifyPassword(currentPassword, req.user.passwordHash)) { res.status(401).json({ erro: "Senha atual incorreta" }); return; }
    req.user.passwordHash = await hashPassword(newPassword);
    res.json({ sucesso: true });
  });

  // ── WALLET (all behind authMiddleware) ───────────────────────────────────

  app.post("/wallet/connect", authMiddleware as express.RequestHandler, (req: any, res) => {
    wallets[req.userId] = { userId: req.userId, publicKey: "7xKpQmN3BvW8rT2cY6uL9dF4eA1sG7hJ0iO", solBalance: 2.4521, usdcBalance: 847.3, network: "devnet", createdAt: new Date().toISOString() };
    res.json(wallets[req.userId]);
  });

  app.post("/wallet/create", authMiddleware as express.RequestHandler, async (req: any, res) => {
    try {
      const { Keypair } = await import("@solana/web3.js");
      const kp = Keypair.generate();
      wallets[req.userId] = { userId: req.userId, publicKey: kp.publicKey.toBase58(), solBalance: 0, usdcBalance: 0, network: "devnet", isNew: true, createdAt: new Date().toISOString() };
    } catch {
      wallets[req.userId] = { userId: req.userId, publicKey: `DEMO${crypto.randomBytes(16).toString("hex").toUpperCase()}`, solBalance: 0, usdcBalance: 0, network: "devnet", isNew: true, createdAt: new Date().toISOString() };
    }
    res.json(wallets[req.userId]);
  });

  app.get("/wallet", authMiddleware as express.RequestHandler, (req: any, res) => { res.json(wallets[req.userId] || null); });
  app.delete("/wallet", authMiddleware as express.RequestHandler, (req: any, res) => { delete wallets[req.userId]; res.json({ sucesso: true }); });

  app.post("/wallet/send", authMiddleware as express.RequestHandler, async (req: any, res) => {
    const { destination, amount } = req.body;
    if (!destination || typeof amount !== "number" || amount <= 0) { res.status(400).json({ erro: "Parâmetros inválidos" }); return; }
    const wallet = wallets[req.userId];
    if (!wallet) { res.status(404).json({ erro: "Carteira não encontrada" }); return; }
    if (wallet.solBalance < amount) { res.status(400).json({ erro: "Saldo SOL insuficiente" }); return; }
    wallet.solBalance = +(wallet.solBalance - amount).toFixed(6);
    const txHash = await gravaAuditTrail({ type: "SEND_SOL", from: wallet.publicKey, to: destination, amount, timestamp: new Date().toISOString() });
    res.json({ sucesso: true, txHash, wallet });
  });

  // ── CARD (all behind authMiddleware) ─────────────────────────────────────

  app.post("/card/create", authMiddleware as express.RequestHandler, (req: any, res) => {
    const cardNum = Array.from({ length: 4 }, () => Math.floor(Math.random() * 9000 + 1000).toString()).join(" ");
    const cvv = Math.floor(Math.random() * 900 + 100).toString();
    const expD = new Date(); expD.setFullYear(expD.getFullYear() + 3);
    const expiry = `${String(expD.getMonth() + 1).padStart(2, "0")}/${String(expD.getFullYear()).slice(-2)}`;
    cards[req.userId] = { id: `card-${crypto.randomUUID()}`, userId: req.userId, number: cardNum, cvv, expiry, holderName: req.user.name.toUpperCase(), balance: 0, usdcBalance: 0, network: "Mastercard Virtual", status: "active", createdAt: new Date().toISOString() };
    cardTxs[req.userId] = [
      { id: `ctx-${crypto.randomUUID()}`, merchant: "Amazon.com.br", amountBRL: 89.9, usdcDeducted: 17.98, date: addDays(now, -2), type: "purchase" },
      { id: `ctx-${crypto.randomUUID()}`, merchant: "Spotify", amountBRL: 21.9, usdcDeducted: 4.38, date: addDays(now, -5), type: "purchase" },
    ];
    res.json({ card: cards[req.userId], transactions: cardTxs[req.userId] });
  });

  app.get("/card", authMiddleware as express.RequestHandler, (req: any, res) => { res.json({ card: cards[req.userId] || null, transactions: cardTxs[req.userId] || [] }); });

  app.post("/card/fund", authMiddleware as express.RequestHandler, (req: any, res) => {
    const { usdcAmount } = req.body;
    if (typeof usdcAmount !== "number" || usdcAmount <= 0) { res.status(400).json({ erro: "Valor inválido" }); return; }
    const card = cards[req.userId]; const wallet = wallets[req.userId];
    if (!card) { res.status(404).json({ erro: "Cartão não encontrado" }); return; }
    if (!wallet) { res.status(400).json({ erro: "Carteira não conectada" }); return; }
    if (wallet.usdcBalance < usdcAmount) { res.status(400).json({ erro: "Saldo USDC insuficiente" }); return; }
    wallet.usdcBalance = +(wallet.usdcBalance - usdcAmount).toFixed(2);
    card.usdcBalance = +(card.usdcBalance + usdcAmount).toFixed(2);
    card.balance = +(card.usdcBalance * 5.0).toFixed(2);
    const tx: CardTx = { id: `ctx-${crypto.randomUUID()}`, merchant: "Carregamento USDC", amountBRL: +(usdcAmount * 5.0).toFixed(2), usdcDeducted: -usdcAmount, date: new Date().toISOString().split("T")[0], type: "fund" };
    if (!cardTxs[req.userId]) cardTxs[req.userId] = [];
    cardTxs[req.userId].unshift(tx);
    res.json({ card, wallet, transactions: cardTxs[req.userId] });
  });

  app.patch("/card/status", authMiddleware as express.RequestHandler, (req: any, res) => {
    const { status } = req.body;
    if (status !== "active" && status !== "blocked") { res.status(400).json({ erro: "Status inválido" }); return; }
    const card = cards[req.userId];
    if (!card) { res.status(404).json({ erro: "Cartão não encontrado" }); return; }
    card.status = status; res.json(card);
  });

  app.post("/card/purchase", authMiddleware as express.RequestHandler, (req: any, res) => {
    const { merchant, amountBRL } = req.body;
    if (!merchant || typeof amountBRL !== "number" || amountBRL <= 0) { res.status(400).json({ erro: "Parâmetros inválidos" }); return; }
    const card = cards[req.userId];
    if (!card) { res.status(404).json({ erro: "Cartão não encontrado" }); return; }
    if (card.status === "blocked") { res.status(400).json({ erro: "Cartão bloqueado" }); return; }
    const usdcNeeded = +(amountBRL / 5.0).toFixed(2);
    if (card.usdcBalance < usdcNeeded) { res.status(400).json({ erro: "Saldo insuficiente no cartão" }); return; }
    card.usdcBalance = +(card.usdcBalance - usdcNeeded).toFixed(2);
    card.balance = +(card.usdcBalance * 5.0).toFixed(2);
    const tx: CardTx = { id: `ctx-${crypto.randomUUID()}`, merchant: String(merchant).slice(0, 100), amountBRL, usdcDeducted: usdcNeeded, date: new Date().toISOString().split("T")[0], type: "purchase" };
    if (!cardTxs[req.userId]) cardTxs[req.userId] = [];
    cardTxs[req.userId].unshift(tx);
    res.json({ card, transactions: cardTxs[req.userId] });
  });

  // ── DEFI (nfes and operacoes scoped to authenticated user) ────────────────

  app.get("/health", (_req, res) => { res.json({ status: "online", network: "devnet", wallet: "FinOpsHub-devnet", solBalance: 1.5, gasOk: true, timestamp: new Date().toISOString() }); });

  app.get("/nfes", authMiddleware as express.RequestHandler, (req: any, res) => {
    const userNfes = nfes.filter((n) => n.userId === req.userId);
    res.json({ nfes: userNfes, totalPendente: userNfes.filter((n) => n.status === "pendente").reduce((s, n) => s + n.valor, 0) });
  });

  app.post("/antecipar/simular", authMiddleware as express.RequestHandler, (req: any, res) => {
    const nfe = nfes.find((n) => n.id === req.body.nfeId && n.userId === req.userId);
    if (!nfe) { res.status(404).json({ erro: "NF-e não encontrada" }); return; }
    res.json({ nfe, quote: simulateDeFiProtocol(nfe.valor, nfe.diasVencimento) });
  });

  app.post("/antecipar/executar", authMiddleware as express.RequestHandler, async (req: any, res) => {
    const nfe = nfes.find((n) => n.id === req.body.nfeId && n.userId === req.userId);
    if (!nfe) { res.status(404).json({ erro: "NF-e não encontrada" }); return; }
    if (nfe.status === "antecipada") { res.status(400).json({ erro: "NF-e já antecipada" }); return; }
    const quote = simulateDeFiProtocol(nfe.valor, nfe.diasVencimento);
    const txHash = await gravaAuditTrail({ type: "ANTECIPAR_NFE", nfeId: nfe.id, userId: req.userId, valor: nfe.valor, quote, timestamp: new Date().toISOString() });
    nfe.status = "antecipada"; nfe.txHash = txHash;
    const operacao: Operacao = { id: `op-${crypto.randomUUID()}`, userId: req.userId, nfeId: nfe.id, nfeNumero: nfe.numero, cliente: nfe.cliente, valorOriginalBRL: nfe.valor, liquidoBRL: quote.liquidoBRL, custoTotalBRL: quote.custoTotalBRL, txHash, timestamp: new Date().toISOString() };
    operacoes.unshift(operacao);
    res.json({ sucesso: true, operacao, quote });
  });

  app.get("/operacoes", authMiddleware as express.RequestHandler, (req: any, res) => {
    res.json(operacoes.filter((o) => o.userId === req.userId));
  });

  app.post("/airdrop", authMiddleware as express.RequestHandler, async (req: any, res) => {
    const wallet = wallets[req.userId];
    if (!wallet) { res.status(404).json({ erro: "Carteira não encontrada" }); return; }
    try {
      const { Connection, PublicKey, LAMPORTS_PER_SOL } = await import("@solana/web3.js");
      const conn = new Connection("https://api.devnet.solana.com", "confirmed");
      const sig = await conn.requestAirdrop(new PublicKey(wallet.publicKey), 0.5 * LAMPORTS_PER_SOL);
      await conn.confirmTransaction(sig);
      wallet.solBalance = +(wallet.solBalance + 0.5).toFixed(4);
      res.json({ sucesso: true, txHash: sig, wallet });
    } catch {
      wallet.solBalance = +(wallet.solBalance + 0.5).toFixed(4);
      res.json({ sucesso: true, txHash: `OFFLINE_${crypto.randomBytes(8).toString("hex")}`, wallet });
    }
  });

  // ── Static files ──────────────────────────────────────────────────────────

  const staticPath = process.env.NODE_ENV === "production"
    ? path.resolve(__dirname, "public")
    : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));
  app.get("*", (_req, res) => { res.sendFile(path.join(staticPath, "index.html")); });

  const httpServer = createServer(app);
  const port = process.env.PORT || 3000;
  httpServer.listen(port, () => { console.log(`FinOpsHub server running on http://localhost:${port}/`); });
}

startServer().catch(console.error);
