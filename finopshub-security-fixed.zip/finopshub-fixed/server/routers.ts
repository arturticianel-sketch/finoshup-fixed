import crypto from "crypto";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import bcrypt from "bcrypt";

const BCRYPT_ROUNDS = 12;

// ─── Helpers ──────────────────────────────────────────────────────────────────
async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, BCRYPT_ROUNDS);
}
async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

function generateCardNumber(): string {
  return Array.from({ length: 4 }, () =>
    Math.floor(Math.random() * 9000 + 1000).toString()
  ).join(" ");
}
function generateCVV(): string {
  return Math.floor(Math.random() * 900 + 100).toString();
}
function generateExpiry(): string {
  const d = new Date();
  d.setFullYear(d.getFullYear() + 3);
  return `${String(d.getMonth() + 1).padStart(2, "0")}/${String(d.getFullYear()).slice(-2)}`;
}
function generateSolanaAddress(): string {
  const chars = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
  return Array.from({ length: 44 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
}
function generateTxHash(): string {
  return crypto.randomBytes(32).toString("hex").toUpperCase().slice(0, 64);
}

// ─── In-memory stores ─────────────────────────────────────────────────────────
interface LocalUser {
  id: string; name: string; email: string;
  passwordHash?: string; provider: "email" | "google"; avatar: string;
}
interface Wallet {
  userId: string; publicKey: string; solBalance: number;
  usdcBalance: number; network: string; createdAt: string;
}
interface VirtualCard {
  id: string; userId: string; number: string; cvv: string; expiry: string;
  holderName: string; balance: number; usdcBalance: number; status: "active" | "blocked";
}
interface CardTx {
  id: string; userId: string; cardId: string; type: "fund" | "purchase";
  merchant: string; amountBRL: number; usdcDeducted: number; date: string;
}
interface NFe {
  id: string; userId: string; numero: string; cliente: string; valor: number;
  vencimento: string; diasVencimento: number; status: "pendente" | "antecipada" | "vencida"; txHash?: string;
}
interface Operacao {
  id: string; userId: string; nfeId: string; nfeNumero: string; cliente: string;
  valorOriginalBRL: number; liquidoBRL: number; txHash: string; createdAt: string;
}

// No demo seed — users register via localAuth.register
const localUsers: LocalUser[] = [];
const wallets: Map<string, Wallet> = new Map();
const virtualCards: Map<string, VirtualCard> = new Map();
const cardTxs: Map<string, CardTx[]> = new Map();
const nfes: NFe[] = [];
const operacoes: Operacao[] = [];

function seedNfesForUser(userId: string) {
  if (nfes.some((n) => n.userId === userId)) return;
  nfes.push(
    { id: `${userId}-1`, userId, numero: "NF-2024-001", cliente: "Empresa Alpha Ltda", valor: 45000, vencimento: "2025-05-15", diasVencimento: 30, status: "pendente" },
    { id: `${userId}-2`, userId, numero: "NF-2024-002", cliente: "Beta Tecnologia S.A.", valor: 28500, vencimento: "2025-05-20", diasVencimento: 35, status: "pendente" },
    { id: `${userId}-3`, userId, numero: "NF-2024-003", cliente: "Gamma Serviços ME", valor: 12000, vencimento: "2025-04-30", diasVencimento: 15, status: "pendente" },
    { id: `${userId}-4`, userId, numero: "NF-2024-004", cliente: "Delta Corp", valor: 67800, vencimento: "2025-06-01", diasVencimento: 47, status: "antecipada", txHash: "DEMO_HASH_ALREADY_DONE_001" }
  );
  operacoes.push({
    id: `${userId}-op-1`, userId, nfeId: `${userId}-4`, nfeNumero: "NF-2024-004",
    cliente: "Delta Corp", valorOriginalBRL: 67800, liquidoBRL: 44982,
    txHash: "DEMO_HASH_ALREADY_DONE_001", createdAt: new Date().toISOString(),
  });
}

// ─── tRPC Routers ─────────────────────────────────────────────────────────────
export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ── Local Auth (email/password) ──────────────────────────────────────────
  localAuth: router({
    login: publicProcedure
      .input(z.object({ email: z.string().email(), password: z.string().min(1) }))
      .mutation(async ({ input }) => {
        const user = localUsers.find((u) => u.email === input.email.toLowerCase().trim());
        // Constant-time compare to prevent user enumeration
        const dummyHash = "$2b$12$invalidhashpaddingtopreventinenumeration000000000000000";
        const valid = user?.passwordHash
          ? await verifyPassword(input.password, user.passwordHash)
          : await bcrypt.compare(input.password, dummyHash).then(() => false);
        if (!valid || !user) throw new Error("Email ou senha incorretos");
        seedNfesForUser(user.id);
        return { user: { id: user.id, name: user.name, email: user.email, avatar: user.avatar, provider: user.provider } };
      }),

    register: publicProcedure
      .input(z.object({
        name: z.string().min(2).max(100),
        email: z.string().email(),
        password: z.string().min(8, "Senha deve ter no mínimo 8 caracteres"),
      }))
      .mutation(async ({ input }) => {
        const normalizedEmail = input.email.toLowerCase().trim();
        if (localUsers.find((u) => u.email === normalizedEmail)) throw new Error("Email já cadastrado");
        const newUser: LocalUser = {
          id: `user-${crypto.randomUUID()}`,
          name: input.name.trim(),
          email: normalizedEmail,
          passwordHash: await hashPassword(input.password),
          provider: "email",
          avatar: input.name.trim().split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase(),
        };
        localUsers.push(newUser);
        seedNfesForUser(newUser.id);
        return { user: { id: newUser.id, name: newUser.name, email: newUser.email, avatar: newUser.avatar, provider: newUser.provider } };
      }),

    // Note: updateProfile and changePassword use protectedProcedure so only
    // authenticated users can modify their own data
    updateProfile: protectedProcedure
      .input(z.object({ name: z.string().min(2).max(100) }))
      .mutation(({ input, ctx }) => {
        const user = localUsers.find((u) => u.id === ctx.user.openId);
        if (!user) throw new Error("Usuário não encontrado");
        user.name = input.name.trim();
        user.avatar = input.name.trim().split(" ").slice(0, 2).map((w) => w[0]).join("").toUpperCase();
        return { id: user.id, name: user.name, email: user.email, avatar: user.avatar, provider: user.provider };
      }),

    changePassword: protectedProcedure
      .input(z.object({ currentPassword: z.string(), newPassword: z.string().min(8) }))
      .mutation(async ({ input, ctx }) => {
        const user = localUsers.find((u) => u.id === ctx.user.openId);
        if (!user) throw new Error("Usuário não encontrado");
        if (user.provider === "google") throw new Error("Usuários Google não podem alterar senha");
        if (!await verifyPassword(input.currentPassword, user.passwordHash!)) throw new Error("Senha atual incorreta");
        user.passwordHash = await hashPassword(input.newPassword);
        return { success: true };
      }),
  }),

  // ── Wallet (all protected) ────────────────────────────────────────────────
  wallet: router({
    get: protectedProcedure.query(({ ctx }) => {
      return wallets.get(ctx.user.openId) ?? null;
    }),

    create: protectedProcedure.mutation(({ ctx }) => {
      if (wallets.has(ctx.user.openId)) throw new Error("Carteira já existe");
      const wallet: Wallet = {
        userId: ctx.user.openId, publicKey: generateSolanaAddress(),
        solBalance: 0, usdcBalance: 0, network: "devnet", createdAt: new Date().toISOString(),
      };
      wallets.set(ctx.user.openId, wallet);
      return { wallet, isNew: true };
    }),

    connect: protectedProcedure.mutation(({ ctx }) => {
      let wallet = wallets.get(ctx.user.openId);
      if (!wallet) {
        wallet = { userId: ctx.user.openId, publicKey: generateSolanaAddress(), solBalance: 2.5, usdcBalance: 150, network: "devnet", createdAt: new Date().toISOString() };
        wallets.set(ctx.user.openId, wallet);
      }
      return { wallet };
    }),

    disconnect: protectedProcedure.mutation(({ ctx }) => {
      wallets.delete(ctx.user.openId);
      return { success: true };
    }),

    airdrop: protectedProcedure.mutation(({ ctx }) => {
      const wallet = wallets.get(ctx.user.openId);
      if (!wallet) throw new Error("Carteira não encontrada");
      wallet.solBalance = +(wallet.solBalance + 1).toFixed(4);
      wallet.usdcBalance = +(wallet.usdcBalance + 10).toFixed(2);
      return { sucesso: true, txHash: `AIRDROP_${generateTxHash().slice(0, 16)}`, wallet };
    }),

    send: protectedProcedure
      .input(z.object({ destination: z.string().min(1), amount: z.number().positive() }))
      .mutation(({ input, ctx }) => {
        const wallet = wallets.get(ctx.user.openId);
        if (!wallet) throw new Error("Carteira não encontrada");
        if (wallet.solBalance < input.amount) throw new Error("Saldo insuficiente");
        wallet.solBalance = +(wallet.solBalance - input.amount - 0.000005).toFixed(6);
        return { sucesso: true, txHash: `SEND_${generateTxHash().slice(0, 16)}`, wallet };
      }),
  }),

  // ── Virtual Card (all protected) ─────────────────────────────────────────
  card: router({
    get: protectedProcedure.query(({ ctx }) => virtualCards.get(ctx.user.openId) ?? null),

    getTxs: protectedProcedure.query(({ ctx }) => cardTxs.get(ctx.user.openId) ?? []),

    create: protectedProcedure
      .input(z.object({ holderName: z.string().min(2).max(100) }))
      .mutation(({ input, ctx }) => {
        if (virtualCards.has(ctx.user.openId)) throw new Error("Cartão já existe");
        const card: VirtualCard = {
          id: `card-${crypto.randomUUID()}`, userId: ctx.user.openId,
          number: generateCardNumber(), cvv: generateCVV(), expiry: generateExpiry(),
          holderName: input.holderName.toUpperCase(), balance: 0, usdcBalance: 0, status: "active",
        };
        virtualCards.set(ctx.user.openId, card);
        cardTxs.set(ctx.user.openId, []);
        return { card };
      }),

    fund: protectedProcedure
      .input(z.object({ usdcAmount: z.number().positive() }))
      .mutation(({ input, ctx }) => {
        const card = virtualCards.get(ctx.user.openId);
        const wallet = wallets.get(ctx.user.openId);
        if (!card) throw new Error("Cartão não encontrado");
        if (!wallet) throw new Error("Carteira não encontrada");
        if (wallet.usdcBalance < input.usdcAmount) throw new Error("Saldo USDC insuficiente");
        const brlAmount = input.usdcAmount * 5;
        wallet.usdcBalance = +(wallet.usdcBalance - input.usdcAmount).toFixed(2);
        card.usdcBalance = +(card.usdcBalance + input.usdcAmount).toFixed(2);
        card.balance = +(card.balance + brlAmount).toFixed(2);
        const tx: CardTx = { id: `ctx-${crypto.randomUUID()}`, userId: ctx.user.openId, cardId: card.id, type: "fund", merchant: "Carga via Carteira Solana", amountBRL: brlAmount, usdcDeducted: input.usdcAmount, date: new Date().toLocaleDateString("pt-BR") };
        const txList = cardTxs.get(ctx.user.openId) ?? [];
        txList.unshift(tx);
        cardTxs.set(ctx.user.openId, txList);
        return { card, wallet, tx };
      }),

    toggleStatus: protectedProcedure.mutation(({ ctx }) => {
      const card = virtualCards.get(ctx.user.openId);
      if (!card) throw new Error("Cartão não encontrado");
      card.status = card.status === "active" ? "blocked" : "active";
      return { card };
    }),

    purchase: protectedProcedure
      .input(z.object({ merchant: z.string().min(1).max(100), amountBRL: z.number().positive() }))
      .mutation(({ input, ctx }) => {
        const card = virtualCards.get(ctx.user.openId);
        if (!card) throw new Error("Cartão não encontrado");
        if (card.status === "blocked") throw new Error("Cartão bloqueado");
        const usdcAmount = +(input.amountBRL / 5).toFixed(2);
        if (card.usdcBalance < usdcAmount) throw new Error("Saldo insuficiente no cartão");
        card.usdcBalance = +(card.usdcBalance - usdcAmount).toFixed(2);
        card.balance = +(card.balance - input.amountBRL).toFixed(2);
        const tx: CardTx = { id: `ctx-${crypto.randomUUID()}`, userId: ctx.user.openId, cardId: card.id, type: "purchase", merchant: input.merchant, amountBRL: input.amountBRL, usdcDeducted: usdcAmount, date: new Date().toLocaleDateString("pt-BR") };
        const txList = cardTxs.get(ctx.user.openId) ?? [];
        txList.unshift(tx);
        cardTxs.set(ctx.user.openId, txList);
        return { card, tx };
      }),
  }),

  // ── DeFi / Antecipar (all protected) ─────────────────────────────────────
  defi: router({
    health: publicProcedure.query(() => ({ status: "online", network: "devnet" })),

    // NFes and operacoes are scoped to the authenticated user
    nfes: protectedProcedure.query(({ ctx }) => ({
      nfes: nfes.filter((n) => n.userId === ctx.user.openId),
    })),

    operacoes: protectedProcedure.query(({ ctx }) =>
      operacoes.filter((o) => o.userId === ctx.user.openId)
    ),

    simular: protectedProcedure
      .input(z.object({ nfeId: z.string() }))
      .mutation(({ input, ctx }) => {
        const nfe = nfes.find((n) => n.id === input.nfeId && n.userId === ctx.user.openId);
        if (!nfe) throw new Error("NF-e não encontrada");
        if (nfe.status !== "pendente") throw new Error("NF-e não está pendente");
        const usdBRL = 5.0;
        const valorUSDC = +(nfe.valor / usdBRL).toFixed(2);
        const ltvRatio = 0.7; const taxaMes = 0.012; const prazoMeses = nfe.diasVencimento / 30;
        const custoPercent = taxaMes * prazoMeses;
        const custoTotalBRL = +(nfe.valor * custoPercent).toFixed(2);
        const liquidoBRL = +(nfe.valor * ltvRatio - custoTotalBRL).toFixed(2);
        const liquidoUSDC = +(liquidoBRL / usdBRL).toFixed(2);
        const economiaVsFactoring = +(nfe.valor * 0.03 * prazoMeses - custoTotalBRL).toFixed(2);
        return { quote: { nfeId: nfe.id, valorOriginalBRL: nfe.valor, valorUSDC, ltvRatio, custoPercent, custoTotalBRL, liquidoBRL, liquidoUSDC, economiaVsFactoring, protocolo: "Kamino Finance (devnet)" } };
      }),

    executar: protectedProcedure
      .input(z.object({ nfeId: z.string() }))
      .mutation(({ input, ctx }) => {
        const nfe = nfes.find((n) => n.id === input.nfeId && n.userId === ctx.user.openId);
        if (!nfe) throw new Error("NF-e não encontrada");
        if (nfe.status !== "pendente") throw new Error("NF-e já processada");
        const ltvRatio = 0.7; const taxaMes = 0.012; const prazoMeses = nfe.diasVencimento / 30;
        const custoTotalBRL = +(nfe.valor * taxaMes * prazoMeses).toFixed(2);
        const liquidoBRL = +(nfe.valor * ltvRatio - custoTotalBRL).toFixed(2);
        const txHash = generateTxHash();
        nfe.status = "antecipada"; nfe.txHash = txHash;
        const op: Operacao = { id: `op-${crypto.randomUUID()}`, userId: ctx.user.openId, nfeId: nfe.id, nfeNumero: nfe.numero, cliente: nfe.cliente, valorOriginalBRL: nfe.valor, liquidoBRL, txHash, createdAt: new Date().toISOString() };
        operacoes.unshift(op);
        return { operacao: op };
      }),
  }),
});

export type AppRouter = typeof appRouter;
