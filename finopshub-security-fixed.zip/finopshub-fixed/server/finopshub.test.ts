/**
 * FinOpsHub — Security & Functional Test Suite
 *
 * Covers:
 *  - Authentication: login, register, password rules, timing-safe compare
 *  - Authorization: protected routes reject unauthenticated callers
 *  - Wallet: CRUD scoped to authenticated user
 *  - Virtual Card: creation, funding, purchase, toggle, isolation
 *  - DeFi / NF-e: scoped to owner, antecipação flow, idempotency
 *  - Input validation: Zod schemas reject bad input
 */

import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import type { User } from "../drizzle/schema";

// ─── Context helpers ──────────────────────────────────────────────────────────

function anonCtx(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

function userCtx(overrides: Partial<User> = {}): TrpcContext {
  const user: User = {
    id: 1,
    openId: "user-test-001",
    name: "Artur Ticianel",
    email: "artur@finopshub.com",
    loginMethod: "email",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
    ...overrides,
  };
  return {
    user,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

function anotherUserCtx(): TrpcContext {
  return userCtx({ id: 2, openId: "user-test-002", email: "outro@finopshub.com" });
}

// ─── AUTH ─────────────────────────────────────────────────────────────────────

describe("auth.me", () => {
  it("returns null for anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });

  it("returns user object when authenticated", async () => {
    const caller = appRouter.createCaller(userCtx());
    const result = await caller.auth.me();
    expect(result?.email).toBe("artur@finopshub.com");
  });
});

describe("auth.logout", () => {
  it("clears the session cookie and returns success", async () => {
    const cleared: { name: string; opts: Record<string, unknown> }[] = [];
    const ctx = userCtx();
    ctx.res.clearCookie = (name: string, opts: Record<string, unknown>) => {
      cleared.push({ name, opts });
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
    expect(cleared).toHaveLength(1);
    expect(cleared[0]?.opts).toMatchObject({ maxAge: -1, httpOnly: true });
  });
});

// ─── LOCAL AUTH ───────────────────────────────────────────────────────────────

describe("localAuth.register", () => {
  it("registers a new user and returns safe user object", async () => {
    const caller = appRouter.createCaller(anonCtx());
    const result = await caller.localAuth.register({
      name: "Novo Usuário",
      email: `novo_${Date.now()}@test.com`,
      password: "senha_segura_123",
    });
    expect(result.user.name).toBe("Novo Usuário");
    expect(result.user.provider).toBe("email");
    expect(result.user).not.toHaveProperty("passwordHash");
  });

  it("generates avatar initials correctly", async () => {
    const caller = appRouter.createCaller(anonCtx());
    const result = await caller.localAuth.register({
      name: "João Silva",
      email: `joao_${Date.now()}@test.com`,
      password: "senha_segura_123",
    });
    expect(result.user.avatar).toBe("JS");
  });

  it("rejects duplicate email", async () => {
    const caller = appRouter.createCaller(anonCtx());
    const email = `dup_${Date.now()}@test.com`;
    await caller.localAuth.register({ name: "User A", email, password: "senha_segura_123" });
    await expect(
      caller.localAuth.register({ name: "User B", email, password: "outra_senha_123" })
    ).rejects.toThrow("Email já cadastrado");
  });

  it("rejects password shorter than 8 characters", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(
      caller.localAuth.register({ name: "User", email: `short_${Date.now()}@test.com`, password: "abc" })
    ).rejects.toThrow();
  });

  it("rejects invalid email format", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(
      caller.localAuth.register({ name: "User", email: "nao-e-email", password: "senha_segura_123" })
    ).rejects.toThrow();
  });
});

describe("localAuth.login", () => {
  it("logs in with valid credentials", async () => {
    const caller = appRouter.createCaller(anonCtx());
    const email = `login_${Date.now()}@test.com`;
    await caller.localAuth.register({ name: "Login User", email, password: "senha_segura_123" });
    const result = await caller.localAuth.login({ email, password: "senha_segura_123" });
    expect(result.user.email).toBe(email);
    expect(result.user).not.toHaveProperty("passwordHash");
  });

  it("rejects wrong password", async () => {
    const caller = appRouter.createCaller(anonCtx());
    const email = `wrong_${Date.now()}@test.com`;
    await caller.localAuth.register({ name: "Wrong Pass", email, password: "correta_senha_123" });
    await expect(
      caller.localAuth.login({ email, password: "senha_errada_456" })
    ).rejects.toThrow("Email ou senha incorretos");
  });

  it("rejects non-existent email (same error message — no user enumeration)", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(
      caller.localAuth.login({ email: "naoexiste@test.com", password: "qualquer_senha" })
    ).rejects.toThrow("Email ou senha incorretos");
  });

  it("is case-insensitive for email", async () => {
    const caller = appRouter.createCaller(anonCtx());
    const email = `case_${Date.now()}@test.com`;
    await caller.localAuth.register({ name: "Case User", email: email.toUpperCase(), password: "senha_segura_123" });
    const result = await caller.localAuth.login({ email: email.toLowerCase(), password: "senha_segura_123" });
    expect(result.user.email).toBe(email.toLowerCase());
  });
});

describe("localAuth.changePassword", () => {
  it("changes password when current is correct", async () => {
    const email = `chpwd_${Date.now()}@test.com`;
    const registerCaller = appRouter.createCaller(anonCtx());
    const { user } = await registerCaller.localAuth.register({
      name: "Pwd User", email, password: "senha_antiga_123",
    });
    const authedCaller = appRouter.createCaller(userCtx({ openId: user.id }));
    await expect(
      authedCaller.localAuth.changePassword({ currentPassword: "senha_antiga_123", newPassword: "nova_senha_456" })
    ).resolves.toMatchObject({ success: true });
    // Old password no longer works
    await expect(
      registerCaller.localAuth.login({ email, password: "senha_antiga_123" })
    ).rejects.toThrow("Email ou senha incorretos");
    // New password works
    await expect(
      registerCaller.localAuth.login({ email, password: "nova_senha_456" })
    ).resolves.toBeTruthy();
  });

  it("rejects unauthenticated caller", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(
      caller.localAuth.changePassword({ currentPassword: "a", newPassword: "nova_senha_456" })
    ).rejects.toThrow();
  });

  it("rejects new password shorter than 8 chars", async () => {
    const caller = appRouter.createCaller(userCtx());
    await expect(
      caller.localAuth.changePassword({ currentPassword: "irrelevante", newPassword: "curta" })
    ).rejects.toThrow();
  });
});

// ─── AUTHORIZATION — protected routes ────────────────────────────────────────

describe("Authorization: unauthenticated access to protected routes", () => {
  it("wallet.get rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.wallet.get()).rejects.toThrow();
  });

  it("wallet.create rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.wallet.create()).rejects.toThrow();
  });

  it("wallet.send rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.wallet.send({ destination: "abc", amount: 1 })).rejects.toThrow();
  });

  it("card.get rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.card.get()).rejects.toThrow();
  });

  it("card.create rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.card.create({ holderName: "Ghost" })).rejects.toThrow();
  });

  it("card.fund rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.card.fund({ usdcAmount: 10 })).rejects.toThrow();
  });

  it("defi.nfes rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.defi.nfes()).rejects.toThrow();
  });

  it("defi.executar rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.defi.executar({ nfeId: "nfe-1" })).rejects.toThrow();
  });

  it("defi.operacoes rejects anonymous user", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(caller.defi.operacoes()).rejects.toThrow();
  });
});

// ─── DATA ISOLATION — users can't access each other's data ───────────────────

describe("Data isolation: users cannot access each other's data", () => {
  it("wallet: user A cannot see user B's wallet", async () => {
    const callerA = appRouter.createCaller(userCtx({ openId: "iso-wallet-A" }));
    const callerB = appRouter.createCaller(userCtx({ openId: "iso-wallet-B" }));
    await callerA.wallet.connect();
    const walletB = await callerB.wallet.get();
    expect(walletB).toBeNull();
  });

  it("card: user A cannot see user B's card", async () => {
    const callerA = appRouter.createCaller(userCtx({ openId: "iso-card-A" }));
    const callerB = appRouter.createCaller(userCtx({ openId: "iso-card-B" }));
    await callerA.card.create({ holderName: "User A" });
    const cardB = await callerB.card.get();
    expect(cardB).toBeNull();
  });

  it("defi.nfes: user A cannot see user B's NFes", async () => {
    const callerA = appRouter.createCaller(userCtx({ openId: "iso-nfe-A" }));
    const callerB = appRouter.createCaller(userCtx({ openId: "iso-nfe-B" }));
    // trigger seed for A
    const nfesA = await callerA.defi.nfes();
    expect(nfesA.nfes.length).toBeGreaterThan(0);
    // B starts fresh without A's data
    const nfesB = await callerB.defi.nfes();
    const aIds = new Set(nfesA.nfes.map((n) => n.id));
    for (const nfe of nfesB.nfes) {
      expect(aIds.has(nfe.id)).toBe(false);
    }
  });

  it("defi.executar: user B cannot execute user A's NFe", async () => {
    const callerA = appRouter.createCaller(userCtx({ openId: "iso-exec-A" }));
    const callerB = appRouter.createCaller(userCtx({ openId: "iso-exec-B" }));
    const nfesA = await callerA.defi.nfes();
    const pendingNfe = nfesA.nfes.find((n) => n.status === "pendente");
    if (!pendingNfe) return; // skip if no pending NF-e
    await expect(
      callerB.defi.executar({ nfeId: pendingNfe.id })
    ).rejects.toThrow("NF-e não encontrada");
  });

  it("defi.operacoes: user A cannot see user B's operações", async () => {
    const callerA = appRouter.createCaller(userCtx({ openId: "iso-ops-A" }));
    const callerB = appRouter.createCaller(userCtx({ openId: "iso-ops-B" }));
    await callerA.defi.nfes(); // seed A
    const opsA = await callerA.defi.operacoes();
    const opsB = await callerB.defi.operacoes();
    const aIds = new Set(opsA.map((o) => o.id));
    for (const op of opsB) {
      expect(aIds.has(op.id)).toBe(false);
    }
  });
});

// ─── WALLET ───────────────────────────────────────────────────────────────────

describe("wallet", () => {
  it("creates a new wallet with zero balance", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-create-1" }));
    const result = await caller.wallet.create();
    expect(result.wallet.publicKey).toBeTruthy();
    expect(result.wallet.network).toBe("devnet");
    expect(result.wallet.solBalance).toBe(0);
    expect(result.wallet.usdcBalance).toBe(0);
    expect(result.isNew).toBe(true);
  });

  it("throws when trying to create duplicate wallet", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-dup-1" }));
    await caller.wallet.create();
    await expect(caller.wallet.create()).rejects.toThrow("Carteira já existe");
  });

  it("connect returns wallet with demo balance", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-connect-1" }));
    const result = await caller.wallet.connect();
    expect(result.wallet.solBalance).toBeGreaterThan(0);
    expect(result.wallet.usdcBalance).toBeGreaterThan(0);
  });

  it("airdrop increases SOL and USDC balance", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-airdrop-1" }));
    await caller.wallet.create();
    const result = await caller.wallet.airdrop();
    expect(result.sucesso).toBe(true);
    expect(result.txHash).toMatch(/^AIRDROP_/);
    expect(result.wallet.solBalance).toBeGreaterThan(0);
    expect(result.wallet.usdcBalance).toBeGreaterThan(0);
  });

  it("airdrop throws for non-existent wallet", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-airdrop-none" }));
    await expect(caller.wallet.airdrop()).rejects.toThrow("Carteira não encontrada");
  });

  it("send deducts SOL balance", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-send-1" }));
    await caller.wallet.connect(); // gives 2.5 SOL
    const result = await caller.wallet.send({ destination: "DESTPUBKEY", amount: 1.0 });
    expect(result.sucesso).toBe(true);
    expect(result.wallet.solBalance).toBeLessThan(2.5);
    expect(result.txHash).toMatch(/^SEND_/);
  });

  it("send rejects insufficient balance", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-send-broke" }));
    await caller.wallet.create(); // 0 SOL
    await expect(caller.wallet.send({ destination: "DEST", amount: 5.0 })).rejects.toThrow("Saldo insuficiente");
  });

  it("send rejects zero or negative amount", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-send-neg" }));
    await expect(caller.wallet.send({ destination: "DEST", amount: -1 })).rejects.toThrow();
    await expect(caller.wallet.send({ destination: "DEST", amount: 0 })).rejects.toThrow();
  });

  it("disconnect removes wallet", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "wallet-disc-1" }));
    await caller.wallet.connect();
    await caller.wallet.disconnect();
    const wallet = await caller.wallet.get();
    expect(wallet).toBeNull();
  });
});

// ─── VIRTUAL CARD ─────────────────────────────────────────────────────────────

describe("card", () => {
  it("creates card with valid randomly generated fields", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-create-1" }));
    const result = await caller.card.create({ holderName: "Artur T" });
    expect(result.card.number).toMatch(/^\d{4} \d{4} \d{4} \d{4}$/);
    expect(result.card.cvv).toMatch(/^\d{3}$/);
    expect(result.card.expiry).toMatch(/^\d{2}\/\d{2}$/);
    expect(result.card.holderName).toBe("ARTUR T");
    expect(result.card.status).toBe("active");
    expect(result.card.usdcBalance).toBe(0);
  });

  it("rejects duplicate card creation for same user", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-dup-2" }));
    await caller.card.create({ holderName: "User X" });
    await expect(caller.card.create({ holderName: "User X" })).rejects.toThrow("Cartão já existe");
  });

  it("funds card by transferring USDC from wallet", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-fund-1" }));
    await caller.wallet.connect(); // 150 USDC
    await caller.card.create({ holderName: "Fund User" });
    const result = await caller.card.fund({ usdcAmount: 50 });
    expect(result.card.usdcBalance).toBe(50);
    expect(result.wallet.usdcBalance).toBe(100); // 150 - 50
    expect(result.card.balance).toBe(250); // 50 * 5
  });

  it("rejects fund when wallet has insufficient USDC", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-fund-broke" }));
    await caller.wallet.create(); // 0 USDC
    await caller.card.create({ holderName: "Broke User" });
    await expect(caller.card.fund({ usdcAmount: 10 })).rejects.toThrow("Saldo USDC insuficiente");
  });

  it("toggles card status between active and blocked", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-toggle-1" }));
    await caller.card.create({ holderName: "Toggle User" });
    const blocked = await caller.card.toggleStatus();
    expect(blocked.card.status).toBe("blocked");
    const active = await caller.card.toggleStatus();
    expect(active.card.status).toBe("active");
  });

  it("purchase deducts USDC balance", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-purchase-1" }));
    await caller.wallet.connect();
    await caller.card.create({ holderName: "Buyer" });
    await caller.card.fund({ usdcAmount: 100 });
    const result = await caller.card.purchase({ merchant: "Amazon", amountBRL: 50 });
    expect(result.card.usdcBalance).toBe(90); // 100 - (50/5)
    expect(result.tx.merchant).toBe("Amazon");
  });

  it("purchase blocked card throws error", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-purchase-blocked" }));
    await caller.wallet.connect();
    await caller.card.create({ holderName: "Blocked" });
    await caller.card.fund({ usdcAmount: 50 });
    await caller.card.toggleStatus(); // block
    await expect(caller.card.purchase({ merchant: "Loja", amountBRL: 10 })).rejects.toThrow("Cartão bloqueado");
  });

  it("purchase rejects insufficient card balance", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-purchase-insuf" }));
    await caller.wallet.connect();
    await caller.card.create({ holderName: "Insuf" });
    // no fund — usdcBalance = 0
    await expect(caller.card.purchase({ merchant: "Loja", amountBRL: 100 })).rejects.toThrow("Saldo insuficiente");
  });

  it("purchase rejects merchant name longer than 100 chars", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-merchant-len" }));
    await expect(
      caller.card.purchase({ merchant: "A".repeat(101), amountBRL: 10 })
    ).rejects.toThrow();
  });

  it("getTxs returns empty list for new card", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "card-txs-empty" }));
    await caller.card.create({ holderName: "Empty" });
    const txs = await caller.card.getTxs();
    expect(txs).toEqual([]);
  });
});

// ─── DEFI / NF-e ──────────────────────────────────────────────────────────────

describe("defi.health", () => {
  it("returns online status (public endpoint)", async () => {
    const caller = appRouter.createCaller(anonCtx());
    const result = await caller.defi.health();
    expect(result.status).toBe("online");
    expect(result.network).toBe("devnet");
  });
});

describe("defi.nfes", () => {
  it("returns seeded NFes for authenticated user", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "nfe-list-1" }));
    const result = await caller.defi.nfes();
    expect(result.nfes.length).toBeGreaterThan(0);
    expect(result.nfes[0]).toHaveProperty("numero");
    expect(result.nfes[0]).toHaveProperty("valor");
    expect(result.nfes[0]).toHaveProperty("status");
  });

  it("all returned NFes belong to the authenticated user", async () => {
    const openId = "nfe-list-owner";
    const caller = appRouter.createCaller(userCtx({ openId }));
    const result = await caller.defi.nfes();
    for (const nfe of result.nfes) {
      expect((nfe as { userId: string }).userId).toBe(openId);
    }
  });
});

describe("defi.simular", () => {
  it("returns valid quote for pending NFe", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "nfe-sim-1" }));
    const { nfes } = await caller.defi.nfes();
    const pending = nfes.find((n) => n.status === "pendente");
    if (!pending) return;
    const result = await caller.defi.simular({ nfeId: pending.id });
    expect(result.quote.valorOriginalBRL).toBe(pending.valor);
    expect(result.quote.ltvRatio).toBe(0.7);
    expect(result.quote.liquidoBRL).toBeGreaterThan(0);
    expect(result.quote.liquidoBRL).toBeLessThan(pending.valor);
  });

  it("throws for non-existent NFe", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "nfe-sim-notfound" }));
    await caller.defi.nfes(); // seed
    await expect(caller.defi.simular({ nfeId: "nfe-999" })).rejects.toThrow("NF-e não encontrada");
  });

  it("throws for already-antecipada NFe", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "nfe-sim-antec" }));
    const { nfes } = await caller.defi.nfes();
    const antecipada = nfes.find((n) => n.status === "antecipada");
    if (!antecipada) return;
    await expect(caller.defi.simular({ nfeId: antecipada.id })).rejects.toThrow("NF-e não está pendente");
  });
});

describe("defi.executar", () => {
  it("executes antecipação and returns operação with txHash", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "nfe-exec-1" }));
    const { nfes } = await caller.defi.nfes();
    const pending = nfes.find((n) => n.status === "pendente");
    if (!pending) return;
    const result = await caller.defi.executar({ nfeId: pending.id });
    expect(result.operacao.txHash).toBeTruthy();
    expect(result.operacao.liquidoBRL).toBeGreaterThan(0);
    expect(result.operacao.valorOriginalBRL).toBe(pending.valor);
  });

  it("is idempotent — throws when re-executing the same NFe", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "nfe-exec-idem" }));
    const { nfes } = await caller.defi.nfes();
    const pending = nfes.find((n) => n.status === "pendente");
    if (!pending) return;
    await caller.defi.executar({ nfeId: pending.id });
    await expect(caller.defi.executar({ nfeId: pending.id })).rejects.toThrow("NF-e já processada");
  });

  it("executed NFe appears in operacoes list", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "nfe-exec-ops" }));
    const { nfes } = await caller.defi.nfes();
    const pending = nfes.find((n) => n.status === "pendente");
    if (!pending) return;
    const { operacao } = await caller.defi.executar({ nfeId: pending.id });
    const ops = await caller.defi.operacoes();
    expect(ops.some((o) => o.id === operacao.id)).toBe(true);
  });
});

// ─── INPUT VALIDATION ─────────────────────────────────────────────────────────

describe("Input validation", () => {
  it("register: empty name rejected", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(
      caller.localAuth.register({ name: "", email: "a@b.com", password: "senha_segura_123" })
    ).rejects.toThrow();
  });

  it("register: empty email rejected", async () => {
    const caller = appRouter.createCaller(anonCtx());
    await expect(
      caller.localAuth.register({ name: "User", email: "", password: "senha_segura_123" })
    ).rejects.toThrow();
  });

  it("wallet.send: negative amount rejected", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "val-send-neg" }));
    await expect(caller.wallet.send({ destination: "X", amount: -5 })).rejects.toThrow();
  });

  it("card.fund: zero amount rejected", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "val-fund-zero" }));
    await expect(caller.card.fund({ usdcAmount: 0 })).rejects.toThrow();
  });

  it("card.purchase: negative amountBRL rejected", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "val-purchase-neg" }));
    await expect(caller.card.purchase({ merchant: "X", amountBRL: -10 })).rejects.toThrow();
  });

  it("card.create: empty holderName rejected", async () => {
    const caller = appRouter.createCaller(userCtx({ openId: "val-holder-empty" }));
    await expect(caller.card.create({ holderName: "" })).rejects.toThrow();
  });
});
