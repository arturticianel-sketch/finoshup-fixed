/* FinOpsHub — Main Application Component
 * Design: Glassmorphism Premium (dark cosmic gradient, glass cards, indigo accent)
 * All views, modals, auth, data in one file per spec
 */

import React, {
  useState,
  useEffect,
  useCallback,
  useMemo,
  useRef,
} from "react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
} from "recharts";
import Papa from "papaparse";
import {
  Eye,
  EyeOff,
  Sun,
  Moon,
  Bell,
  LogOut,
  Settings,
  Copy,
  X,
  ChevronDown,
  ArrowUpRight,
  ArrowDownLeft,
  ArrowRightLeft,
  CreditCard,
  Zap,
  BarChart2,
  Users,
  FileText,
  TrendingUp,
  Wallet,
  Plus,
  Send,
  Download,
  Upload,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  ExternalLink,
  Shield,
  Lock,
  Unlock,
  QrCode,
  Building2,
  Layers,
  Activity,
  DollarSign,
  Receipt,
  Home,
  Star,
  Info,
  Check,
  Loader2,
} from "lucide-react";
import { useTheme } from "@/contexts/ThemeContext";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { getLoginUrl } from "@/const";

// ─── API Base URL (legacy, using tRPC now) ────────────────────────────────────
const API = "";

// ─── Types ────────────────────────────────────────────────────────────────────
interface AuthUser {
  id: string;
  name: string;
  email: string;
  avatar: string;
  provider: "email" | "google";
}

interface Account {
  id: string;
  bank: string;
  type: string;
  balance: number;
  icon: string;
  gradient: string;
}

interface Transaction {
  id: string;
  date: Date;
  desc: string;
  amount: number;
  cat: string;
  bankId: string;
  type: "income" | "expense";
}

interface Employee {
  id: string;
  name: string;
  cpf: string;
  salary: number;
  dep: number;
  role: string;
  dept: string;
  bankCode: string;
  bankAgency: string;
  bankAccount: string;
}

interface PayrollBatch {
  id: string;
  month: string;
  status: "draft" | "calculated" | "paid";
  totalGross: number;
  totalNet: number;
  totalTaxes: number;
  createdAt: Date;
  paidAt?: Date;
}

interface SolanaWallet {
  publicKey: string;
  solBalance: number;
  usdcBalance: number;
  network: string;
  isNew?: boolean;
}

interface VirtualCard {
  id: string;
  number: string;
  cvv: string;
  expiry: string;
  holderName: string;
  balance: number;
  usdcBalance: number;
  network?: string;
  status: "active" | "blocked";
}

interface CardTx {
  id: string;
  merchant: string;
  amountBRL: number;
  usdcDeducted: number;
  date: string;
  type: "purchase" | "fund";
}

interface NFe {
  id: string;
  numero: string;
  cliente: string;
  valor: number;
  vencimento: string;
  diasVencimento: number;
  status: "pendente" | "antecipada";
  txHash?: string;
}

interface DeFiQuote {
  nfeId?: string;
  valorOriginalBRL: number;
  valorUSDC: number;
  liquidoUSDC: number;
  liquidoBRL: number;
  custoTotalBRL: number;
  custoPercent: number;
  taxaMensalPercent?: number;
  ltvRatio: number;
  diasVencimento?: number;
  economiaVsFactoring: number;
  protocolo: string;
}

interface Operacao {
  id: string;
  nfeId: string;
  nfeNumero: string;
  cliente: string;
  valorOriginalBRL: number;
  liquidoBRL: number;
  custoTotalBRL?: number;
  txHash: string;
  timestamp?: string;
  createdAt?: string;
}

// ─── Initial Data ─────────────────────────────────────────────────────────────
const d = (daysAgo: number) => {
  const dt = new Date();
  dt.setDate(dt.getDate() - daysAgo);
  return dt;
};

const INITIAL_ACCOUNTS: Account[] = [
  { id: "1", bank: "Nubank", type: "Conta Corrente", balance: 24250.5, icon: "💜", gradient: "from-violet-600 to-purple-900" },
  { id: "2", bank: "Itaú", type: "Investimentos", balance: 62800.0, icon: "🏦", gradient: "from-amber-500 to-orange-700" },
  { id: "3", bank: "Inter", type: "Conta Digital", balance: 11120.25, icon: "🟠", gradient: "from-orange-500 to-red-600" },
  { id: "4", bank: "XP", type: "Corretora", balance: 45400.0, icon: "📈", gradient: "from-emerald-500 to-teal-700" },
];

const INITIAL_TRANSACTIONS: Transaction[] = [
  { id: "t1", date: d(0), desc: "Supermercado Pão de Açúcar", amount: 342.5, cat: "Alimentação", bankId: "1", type: "expense" },
  { id: "t2", date: d(1), desc: "Salário Empresa Tech", amount: 7500.0, cat: "Renda", bankId: "2", type: "income" },
  { id: "t3", date: d(1), desc: "Netflix", amount: 55.9, cat: "Lazer", bankId: "3", type: "expense" },
  { id: "t4", date: d(2), desc: "Posto Shell", amount: 210.0, cat: "Transporte", bankId: "1", type: "expense" },
  { id: "t5", date: d(3), desc: "Rendimento CDB", amount: 624.3, cat: "Investimentos", bankId: "4", type: "income" },
  { id: "t6", date: d(4), desc: "Farmácia Drogasil", amount: 89.9, cat: "Saúde", bankId: "3", type: "expense" },
  { id: "t7", date: d(5), desc: "Pagamento Folha - Abril", amount: 48200.0, cat: "Folha", bankId: "1", type: "expense" },
  { id: "t8", date: d(6), desc: "Freelance Design System", amount: 3200.0, cat: "Renda", bankId: "1", type: "income" },
  { id: "t9", date: d(7), desc: "AWS Cloud Services", amount: 1850.0, cat: "Infraestrutura", bankId: "2", type: "expense" },
  { id: "t10", date: d(8), desc: "Uber / 99 Rides", amount: 178.4, cat: "Transporte", bankId: "3", type: "expense" },
];

const INITIAL_EMPLOYEES: Employee[] = [
  { id: "e1", name: "Ana Beatriz Costa", cpf: "12345678901", salary: 8500, dep: 2, role: "Desenvolvedora Sr.", dept: "Tecnologia", bankCode: "260", bankAgency: "0001", bankAccount: "12345-6" },
  { id: "e2", name: "Carlos Eduardo Lima", cpf: "23456789012", salary: 6200, dep: 1, role: "Designer UX", dept: "Produto", bankCode: "341", bankAgency: "1234", bankAccount: "54321-0" },
  { id: "e3", name: "Daniela Ferreira", cpf: "34567890123", salary: 12000, dep: 0, role: "Gerente de Projetos", dept: "Operações", bankCode: "001", bankAgency: "4321", bankAccount: "11111-2" },
  { id: "e4", name: "Eduardo Santos", cpf: "45678901234", salary: 5800, dep: 3, role: "Analista Financeiro", dept: "Financeiro", bankCode: "033", bankAgency: "0002", bankAccount: "22222-3" },
  { id: "e5", name: "Fernanda Oliveira", cpf: "56789012345", salary: 9200, dep: 1, role: "Tech Lead", dept: "Tecnologia", bankCode: "260", bankAgency: "0001", bankAccount: "33333-4" },
  { id: "e6", name: "Gabriel Mendes", cpf: "67890123456", salary: 4500, dep: 0, role: "Estagiário", dept: "Marketing", bankCode: "077", bankAgency: "0003", bankAccount: "44444-5" },
  { id: "e7", name: "Helena Rodrigues", cpf: "78901234567", salary: 15000, dep: 2, role: "Diretora Comercial", dept: "Comercial", bankCode: "341", bankAgency: "5678", bankAccount: "55555-6" },
  { id: "e8", name: "Igor Nascimento", cpf: "89012345678", salary: 7800, dep: 1, role: "DevOps Engineer", dept: "Tecnologia", bankCode: "260", bankAgency: "0001", bankAccount: "66666-7" },
];

const addDays = (d: Date, n: number) => {
  const r = new Date(d);
  r.setDate(r.getDate() + n);
  return r;
};

const INITIAL_BATCHES: PayrollBatch[] = [
  { id: "b1", month: "2026-04", status: "calculated", totalGross: 69000, totalNet: 48200, totalTaxes: 20800, createdAt: d(5) },
  { id: "b2", month: "2026-03", status: "paid", totalGross: 68500, totalNet: 47900, totalTaxes: 20600, createdAt: d(35), paidAt: d(30) },
  { id: "b3", month: "2026-02", status: "paid", totalGross: 67200, totalNet: 47100, totalTaxes: 20100, createdAt: d(65), paidAt: d(60) },
];

// ─── Formatters ───────────────────────────────────────────────────────────────
const fmtBRL = (v: number) =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(v);

const fmtCPF = (cpf: string) =>
  cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");

const fmtDate = (d: Date | string) => {
  const dt = typeof d === "string" ? new Date(d) : d;
  return dt.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
};

const fmtMonth = (m: string) => {
  const [y, mo] = m.split("-");
  const months = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"];
  return `${months[parseInt(mo) - 1]}/${y}`;
};

const truncateKey = (key: string) =>
  key.length > 12 ? `${key.slice(0, 4)}...${key.slice(-4)}` : key;

// ─── CLT Payroll Engine ───────────────────────────────────────────────────────
function calcINSS(salary: number): number {
  if (salary <= 1412.0) return salary * 0.075;
  if (salary <= 2666.68) return salary * 0.09 - 21.18;
  if (salary <= 4000.03) return salary * 0.12 - 101.18;
  if (salary <= 7786.02) return salary * 0.14 - 181.18;
  return 7786.02 * 0.14 - 181.18;
}

function calcIRRF(base: number): number {
  if (base <= 2112.0) return 0;
  if (base <= 2826.65) return base * 0.075 - 158.4;
  if (base <= 3751.05) return base * 0.15 - 370.4;
  if (base <= 4664.68) return base * 0.225 - 651.73;
  return base * 0.275 - 884.96;
}

function calcEmployee(emp: Employee) {
  const gross = emp.salary;
  const inss = calcINSS(gross);
  const deductDep = emp.dep * 189.59;
  const irrfBase = gross - inss - deductDep;
  const irrf = Math.max(0, calcIRRF(irrfBase));
  const fgts = gross * 0.08;
  const net = gross - inss - irrf;
  return { gross, inss, irrf, fgts, net, deductDep, irrfBase };
}

// ─── QR Code SVG Generator ────────────────────────────────────────────────────
function QRCodeSVG({ seed, size = 200 }: { seed: string; size?: number }) {
  const modules = 21;
  const cellSize = size / modules;
  const hash = seed.split("").reduce((a, c) => (a * 31 + c.charCodeAt(0)) & 0xffffffff, 0);

  const bits: boolean[][] = Array.from({ length: modules }, (_, r) =>
    Array.from({ length: modules }, (_, c) => {
      // Corner finder patterns
      if ((r < 7 && c < 7) || (r < 7 && c >= modules - 7) || (r >= modules - 7 && c < 7)) {
        const fr = r < 7 ? r : r - (modules - 7);
        const fc = c < 7 ? c : c - (modules - 7);
        if (fr === 0 || fr === 6 || fc === 0 || fc === 6) return true;
        if (fr >= 2 && fr <= 4 && fc >= 2 && fc <= 4) return true;
        return false;
      }
      // Data modules
      const idx = r * modules + c;
      return ((hash >> (idx % 32)) & 1) === 1;
    })
  );

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} xmlns="http://www.w3.org/2000/svg">
      <rect width={size} height={size} fill="white" />
      {bits.map((row, r) =>
        row.map((on, c) =>
          on ? (
            <rect
              key={`${r}-${c}`}
              x={c * cellSize}
              y={r * cellSize}
              width={cellSize}
              height={cellSize}
              fill="#000"
            />
          ) : null
        )
      )}
    </svg>
  );
}

// ─── AnimatedCounter ──────────────────────────────────────────────────────────
function AnimatedCounter({ value, prefix = "", suffix = "", decimals = 2, className = "" }: {
  value: number; prefix?: string; suffix?: string; decimals?: number; className?: string;
}) {
  const [display, setDisplay] = useState(0);
  const startRef = useRef<number | null>(null);
  const frameRef = useRef<number>(0);

  useEffect(() => {
    const duration = 500;
    const start = performance.now();
    startRef.current = start;
    const animate = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplay(value * eased);
      if (progress < 1) frameRef.current = requestAnimationFrame(animate);
    };
    frameRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameRef.current);
  }, [value]);

  const formatted = new Intl.NumberFormat("pt-BR", {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(display);

  return (
    <span className={`font-mono-finance ${className}`}>
      {prefix}{formatted}{suffix}
    </span>
  );
}

// ─── MiniSparkline ────────────────────────────────────────────────────────────
function MiniSparkline({ data, color = "#6366f1" }: { data: number[]; color?: string }) {
  const chartData = data.map((v, i) => ({ v, i }));
  return (
    <ResponsiveContainer width={80} height={32}>
      <AreaChart data={chartData} margin={{ top: 2, right: 0, left: 0, bottom: 2 }}>
        <defs>
          <linearGradient id={`sg-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={color} stopOpacity={0.4} />
            <stop offset="95%" stopColor={color} stopOpacity={0} />
          </linearGradient>
        </defs>
        <Area type="monotone" dataKey="v" stroke={color} strokeWidth={1.5} fill={`url(#sg-${color.replace("#", "")})`} dot={false} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

// ─── Toast system ─────────────────────────────────────────────────────────────
// Using sonner via import { toast } from "sonner"

// ─── Modal wrapper ────────────────────────────────────────────────────────────
function Modal({ open, onClose, children, maxWidth = "max-w-lg" }: {
  open: boolean; onClose: () => void; children: React.ReactNode; maxWidth?: string;
}) {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === "Escape") onClose(); };
    if (open) document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 modal-backdrop" onClick={onClose}>
      <div
        className={`glass-card w-full ${maxWidth} max-h-[90vh] overflow-y-auto modal-enter`}
        style={{ background: "rgba(13,11,29,0.95)", border: "1px solid rgba(255,255,255,0.1)" }}
        onClick={(e) => e.stopPropagation()}
      >
        {children}
      </div>
    </div>
  );
}

// ─── StatusBadge ─────────────────────────────────────────────────────────────
function StatusBadge({ status }: { status: "draft" | "calculated" | "paid" | "pendente" | "antecipada" | "active" | "blocked" }) {
  const map = {
    draft: { label: "Rascunho", cls: "badge-draft" },
    calculated: { label: "Calculado", cls: "badge-calculated" },
    paid: { label: "Pago", cls: "badge-paid" },
    pendente: { label: "Pendente", cls: "badge-calculated" },
    antecipada: { label: "Antecipada", cls: "badge-paid" },
    active: { label: "Ativo", cls: "badge-paid" },
    blocked: { label: "Bloqueado", cls: "bg-red-500/15 text-red-400 border border-red-500/30" },
  };
  const { label, cls } = map[status] || map.draft;
  return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${cls}`}>{label}</span>;
}

// ─── Dept Badge ───────────────────────────────────────────────────────────────
function DeptBadge({ dept }: { dept: string }) {
  const colors: Record<string, string> = {
    Tecnologia: "bg-indigo-500/15 text-indigo-400 border border-indigo-500/30",
    Produto: "bg-violet-500/15 text-violet-400 border border-violet-500/30",
    Operações: "bg-amber-500/15 text-amber-400 border border-amber-500/30",
    Financeiro: "bg-emerald-500/15 text-emerald-400 border border-emerald-500/30",
    Marketing: "bg-pink-500/15 text-pink-400 border border-pink-500/30",
    Comercial: "bg-cyan-500/15 text-cyan-400 border border-cyan-500/30",
  };
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${colors[dept] || "bg-slate-500/15 text-slate-400 border border-slate-500/30"}`}>
      {dept}
    </span>
  );
}

// ─── Cat Icon ─────────────────────────────────────────────────────────────────
function CatIcon({ cat }: { cat: string }) {
  const map: Record<string, string> = {
    Alimentação: "🍽️", Renda: "💰", Lazer: "🎬", Transporte: "🚗",
    Investimentos: "📈", Saúde: "💊", Folha: "👥", Infraestrutura: "☁️",
    Boleto: "📄", Utilidades: "⚡", "Cartão Crédito": "💳", PIX: "⚡",
    "Depósito via PIX": "💸", "Depósito TED": "🏦",
  };
  return <span>{map[cat] || "💳"}</span>;
}

// ─── Login Screen ─────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: (user: AuthUser, token: string) => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [confirmPw, setConfirmPw] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const loginMutation = trpc.localAuth.login.useMutation();
  const registerMutation = trpc.localAuth.register.useMutation();

  const handleGoogle = () => {
    // Redirect to Manus OAuth
    window.location.href = getLoginUrl();
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const data = await loginMutation.mutateAsync({ email, password });
      const token = `local_${data.user.id}`;
      localStorage.setItem("finopshub_token", token);
      localStorage.setItem("finopshub_user", JSON.stringify(data.user));
      onLogin(data.user, token);
    } catch (e: any) {
      setError(e.message || "Erro ao fazer login");
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirmPw) { setError("Senhas não coincidem"); return; }
    setLoading(true);
    setError("");
    try {
      const data = await registerMutation.mutateAsync({ name, email, password });
      const token = `local_${data.user.id}`;
      localStorage.setItem("finopshub_token", token);
      localStorage.setItem("finopshub_user", JSON.stringify(data.user));
      onLogin(data.user, token);
    } catch (e: any) {
      setError(e.message || "Erro ao criar conta");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app-bg min-h-screen flex items-center justify-center p-4">
      <div className="glass-card w-full max-w-[420px] p-8 modal-enter">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl btn-primary-gradient mb-4">
            <span className="text-2xl font-bold text-white">F</span>
          </div>
          <h1 className="text-2xl font-bold text-white">FinOpsHub</h1>
          <p className="text-sm mt-1" style={{ color: "rgba(255,255,255,0.4)" }}>
            Plataforma Financeira Corporativa
          </p>
        </div>

        {/* Google Button */}
        <button
          onClick={handleGoogle}
          disabled={loading}
          className="w-full flex items-center justify-center gap-3 py-3 px-4 rounded-xl border mb-4 font-medium transition-all hover:bg-white/5"
          style={{ borderColor: "rgba(255,255,255,0.15)", color: "rgba(255,255,255,0.9)" }}
        >
          <svg width="18" height="18" viewBox="0 0 18 18">
            <path fill="#4285F4" d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 0 0 2.38-5.88c0-.57-.05-.66-.15-1.18z" />
            <path fill="#34A853" d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2a4.8 4.8 0 0 1-7.18-2.54H1.83v2.07A8 8 0 0 0 8.98 17z" />
            <path fill="#FBBC05" d="M4.5 10.52a4.8 4.8 0 0 1 0-3.04V5.41H1.83a8 8 0 0 0 0 7.18l2.67-2.07z" />
            <path fill="#EA4335" d="M8.98 4.18c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 0 0 1.83 5.4L4.5 7.49a4.77 4.77 0 0 1 4.48-3.3z" />
          </svg>
          Entrar com Google
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.1)" }} />
          <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>ou</span>
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.1)" }} />
        </div>

        {/* Email/Password Form */}
        {mode === "login" ? (
          <form onSubmit={handleLogin} className="space-y-3">
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all"
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "rgba(255,255,255,0.9)",
              }}
            />
            <input
              type="password"
              placeholder="Senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-4 py-3 rounded-xl text-sm outline-none transition-all"
              style={{
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                color: "rgba(255,255,255,0.9)",
              }}
            />
            {error && <p className="text-red-400 text-xs">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl font-semibold text-sm btn-primary-gradient flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={16} className="animate-spin" />}
              Entrar
            </button>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-3">
            <input
              type="text"
              placeholder="Nome completo"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full px-4 py-3 rounded-xl text-sm outline-none"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
            />
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="w-full px-4 py-3 rounded-xl text-sm outline-none"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
            />
            <input
              type="password"
              placeholder="Senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full px-4 py-3 rounded-xl text-sm outline-none"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
            />
            <input
              type="password"
              placeholder="Confirmar senha"
              value={confirmPw}
              onChange={(e) => setConfirmPw(e.target.value)}
              required
              className="w-full px-4 py-3 rounded-xl text-sm outline-none"
              style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
            />
            {error && <p className="text-red-400 text-xs">{error}</p>}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl font-semibold text-sm btn-primary-gradient flex items-center justify-center gap-2"
            >
              {loading && <Loader2 size={16} className="animate-spin" />}
              Criar Conta
            </button>
          </form>
        )}

        <p className="text-center text-xs mt-4" style={{ color: "rgba(255,255,255,0.4)" }}>
          {mode === "login" ? (
            <>Não tem conta?{" "}
              <button onClick={() => { setMode("register"); setError(""); }} className="text-indigo-400 hover:text-indigo-300">
                Criar conta
              </button>
            </>
          ) : (
            <>Já tem conta?{" "}
              <button onClick={() => { setMode("login"); setError(""); }} className="text-indigo-400 hover:text-indigo-300">
                Entrar
              </button>
            </>
          )}
        </p>

        {/* Demo hint */}
        <div className="mt-4 p-3 rounded-xl text-xs text-center" style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)", color: "rgba(255,255,255,0.5)" }}>
          Demo: <span className="font-mono-finance text-indigo-400">demo@finopshub.com</span> / <span className="font-mono-finance text-indigo-400">demo123</span>
        </div>
      </div>
    </div>
  );
}

// ─── Header ───────────────────────────────────────────────────────────────────
function Header({
  user, mode, setMode, balVis, setBalVis, onLogout, onSettings,
}: {
  user: AuthUser;
  mode: "financas" | "folha";
  setMode: (m: "financas" | "folha") => void;
  balVis: boolean;
  setBalVis: (v: boolean) => void;
  onLogout: () => void;
  onSettings: () => void;
}) {
  const { theme, toggleTheme } = useTheme();
  const [dropOpen, setDropOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const dropRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (dropRef.current && !dropRef.current.contains(e.target as Node)) {
        setDropOpen(false);
        setNotifOpen(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  return (
    <header
      className="sticky top-0 z-40 flex items-center justify-between px-4 lg:px-6 h-14"
      style={{
        background: "rgba(12,10,29,0.85)",
        backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg btn-primary-gradient flex items-center justify-center">
          <span className="text-sm font-bold text-white">F</span>
        </div>
        <span className="font-bold text-sm hidden sm:block" style={{ color: "rgba(255,255,255,0.9)" }}>
          FinOpsHub
        </span>
      </div>

      {/* Mode switcher */}
      <div
        className="flex items-center gap-1 p-1 rounded-xl"
        style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.08)" }}
      >
        <button
          onClick={() => setMode("financas")}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${mode === "financas" ? "btn-primary-gradient text-white" : ""}`}
          style={{ color: mode !== "financas" ? "rgba(255,255,255,0.5)" : undefined }}
        >
          Finanças
        </button>
        <button
          onClick={() => setMode("folha")}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${mode === "folha" ? "btn-primary-gradient text-white" : ""}`}
          style={{ color: mode !== "folha" ? "rgba(255,255,255,0.5)" : undefined }}
        >
          Folha CLT
        </button>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-2" ref={dropRef}>
        <button onClick={() => setBalVis(!balVis)} className="p-2 rounded-lg hover:bg-white/5 transition-all" title="Ocultar valores">
          {balVis ? <Eye size={16} style={{ color: "rgba(255,255,255,0.6)" }} /> : <EyeOff size={16} style={{ color: "rgba(255,255,255,0.6)" }} />}
        </button>
        <button onClick={toggleTheme} className="p-2 rounded-lg hover:bg-white/5 transition-all" title="Tema">
          {theme === "dark" ? <Sun size={16} style={{ color: "rgba(255,255,255,0.6)" }} /> : <Moon size={16} style={{ color: "rgba(255,255,255,0.6)" }} />}
        </button>

        {/* Notifications */}
        <div className="relative">
          <button
            onClick={() => { setNotifOpen(!notifOpen); setDropOpen(false); }}
            className="p-2 rounded-lg hover:bg-white/5 transition-all relative"
          >
            <Bell size={16} style={{ color: "rgba(255,255,255,0.6)" }} />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-indigo-500 pulse-dot" />
          </button>
          {notifOpen && (
            <div
              className="absolute right-0 top-10 w-72 rounded-xl p-3 z-50"
              style={{ background: "rgba(13,11,29,0.98)", border: "1px solid rgba(255,255,255,0.1)" }}
            >
              <p className="text-xs font-semibold mb-2" style={{ color: "rgba(255,255,255,0.6)" }}>Notificações</p>
              <div className="space-y-2">
                <div className="p-2 rounded-lg" style={{ background: "rgba(99,102,241,0.1)" }}>
                  <p className="text-xs font-medium" style={{ color: "rgba(255,255,255,0.9)" }}>Folha de Abril calculada</p>
                  <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>Aguardando pagamento • 5 dias atrás</p>
                </div>
                <div className="p-2 rounded-lg" style={{ background: "rgba(16,185,129,0.1)" }}>
                  <p className="text-xs font-medium" style={{ color: "rgba(255,255,255,0.9)" }}>NF-e 125 antecipada com sucesso</p>
                  <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>R$ 78.120 creditados • 5 dias atrás</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* User avatar */}
        <div className="relative">
          <button
            onClick={() => { setDropOpen(!dropOpen); setNotifOpen(false); }}
            className="flex items-center gap-2 p-1 rounded-xl hover:bg-white/5 transition-all"
          >
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white"
              style={{ background: "linear-gradient(135deg, #6366f1, #9945FF)" }}
            >
              {user.avatar}
            </div>
            <ChevronDown size={12} style={{ color: "rgba(255,255,255,0.4)" }} />
          </button>
          {dropOpen && (
            <div
              className="absolute right-0 top-11 w-52 rounded-xl p-2 z-50"
              style={{ background: "rgba(13,11,29,0.98)", border: "1px solid rgba(255,255,255,0.1)" }}
            >
              <div className="px-3 py-2 mb-1">
                <p className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.9)" }}>{user.name}</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>{user.email}</p>
              </div>
              <div className="h-px mb-1" style={{ background: "rgba(255,255,255,0.06)" }} />
              <button
                onClick={() => { onSettings(); setDropOpen(false); }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm hover:bg-white/5 transition-all"
                style={{ color: "rgba(255,255,255,0.7)" }}
              >
                <Settings size={14} /> Configurações
              </button>
              <button
                onClick={() => { onLogout(); setDropOpen(false); }}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm hover:bg-red-500/10 transition-all text-red-400"
              >
                <LogOut size={14} /> Sair
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

// ─── Finance Sidebar Nav ──────────────────────────────────────────────────────
function FinanceSidebar({ view, setView }: { view: string; setView: (v: string) => void }) {
  const items = [
    { id: "dashboard", icon: <Home size={16} />, label: "Dashboard" },
    { id: "contas", icon: <Building2 size={16} />, label: "Contas" },
    { id: "extrato", icon: <FileText size={16} />, label: "Extrato" },
    { id: "cartoes", icon: <CreditCard size={16} />, label: "Cartões" },
    { id: "crypto", icon: <Wallet size={16} />, label: "Crypto" },
    { id: "antecipar", icon: <TrendingUp size={16} />, label: "Antecipar" },
  ];
  return (
    <aside
      className="hidden lg:flex flex-col w-56 shrink-0 py-4 px-3 gap-1"
      style={{ borderRight: "1px solid rgba(255,255,255,0.06)" }}
    >
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => setView(item.id)}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
            view === item.id
              ? "btn-primary-gradient text-white"
              : "hover:bg-white/5"
          }`}
          style={{ color: view !== item.id ? "rgba(255,255,255,0.55)" : undefined }}
        >
          {item.icon}
          {item.label}
        </button>
      ))}
    </aside>
  );
}

// ─── Payroll Sidebar Nav ──────────────────────────────────────────────────────
function PayrollSidebar({ view, setView }: { view: string; setView: (v: string) => void }) {
  const items = [
    { id: "payroll-dashboard", icon: <BarChart2 size={16} />, label: "Dashboard" },
    { id: "equipe", icon: <Users size={16} />, label: "Equipe" },
    { id: "importar", icon: <Upload size={16} />, label: "Importar CSV" },
    { id: "simulacao", icon: <Activity size={16} />, label: "Simulação" },
  ];
  return (
    <aside
      className="hidden lg:flex flex-col w-56 shrink-0 py-4 px-3 gap-1"
      style={{ borderRight: "1px solid rgba(255,255,255,0.06)" }}
    >
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => setView(item.id)}
          className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
            view === item.id
              ? "btn-primary-gradient text-white"
              : "hover:bg-white/5"
          }`}
          style={{ color: view !== item.id ? "rgba(255,255,255,0.55)" : undefined }}
        >
          {item.icon}
          {item.label}
        </button>
      ))}
    </aside>
  );
}

// ─── Mobile Bottom Nav ────────────────────────────────────────────────────────
function MobileNav({ mode, view, setView }: { mode: "financas" | "folha"; view: string; setView: (v: string) => void }) {
  const finItems = [
    { id: "dashboard", icon: <Home size={18} />, label: "Início" },
    { id: "contas", icon: <Building2 size={18} />, label: "Contas" },
    { id: "crypto", icon: <Wallet size={18} />, label: "Crypto" },
    { id: "antecipar", icon: <TrendingUp size={18} />, label: "DeFi" },
  ];
  const payItems = [
    { id: "payroll-dashboard", icon: <BarChart2 size={18} />, label: "Dashboard" },
    { id: "equipe", icon: <Users size={18} />, label: "Equipe" },
    { id: "importar", icon: <Upload size={18} />, label: "CSV" },
    { id: "simulacao", icon: <Activity size={18} />, label: "Simulação" },
  ];
  const items = mode === "financas" ? finItems : payItems;

  return (
    <nav
      className="lg:hidden fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around px-2 h-16"
      style={{
        background: "rgba(12,10,29,0.95)",
        backdropFilter: "blur(20px)",
        borderTop: "1px solid rgba(255,255,255,0.06)",
      }}
    >
      {items.map((item) => (
        <button
          key={item.id}
          onClick={() => setView(item.id)}
          className="flex flex-col items-center gap-0.5 py-2 px-3 rounded-xl transition-all"
          style={{ color: view === item.id ? "#818cf8" : "rgba(255,255,255,0.4)" }}
        >
          {item.icon}
          <span className="text-[10px]">{item.label}</span>
        </button>
      ))}
    </nav>
  );
}

// ─── Transfer Modal ───────────────────────────────────────────────────────────
function TransferModal({ open, onClose, accounts, onTransfer }: {
  open: boolean; onClose: () => void;
  accounts: Account[];
  onTransfer: (fromId: string, amount: number, dest: string) => void;
}) {
  const [fromId, setFromId] = useState("1");
  const [dest, setDest] = useState("");
  const [amount, setAmount] = useState("");
  const [step, setStep] = useState<"form" | "success">("form");

  const from = accounts.find((a) => a.id === fromId);

  const handleConfirm = () => {
    const amt = parseFloat(amount);
    if (!dest || !amt || amt <= 0) { toast.error("Preencha todos os campos"); return; }
    if (!from || from.balance < amt) { toast.error("Saldo insuficiente"); return; }
    onTransfer(fromId, amt, dest);
    setStep("success");
  };

  const handleClose = () => { setStep("form"); setDest(""); setAmount(""); onClose(); };

  return (
    <Modal open={open} onClose={handleClose}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Transferir</h2>
          <button onClick={handleClose}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
        </div>
        {step === "form" ? (
          <div className="space-y-4">
            <div>
              <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Conta de origem</label>
              <select
                value={fromId}
                onChange={(e) => setFromId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl text-sm"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.id} style={{ background: "#13102b" }}>
                    {a.icon} {a.bank} — {fmtBRL(a.balance)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Destino (nome ou chave PIX)</label>
              <input
                value={dest}
                onChange={(e) => setDest(e.target.value)}
                placeholder="Ex: João da Silva ou CPF/email"
                className="w-full px-3 py-2.5 rounded-xl text-sm"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
              />
            </div>
            <div>
              <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Valor</label>
              <input
                type="number"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0,00"
                className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
              />
            </div>
            <button onClick={handleConfirm} className="w-full py-3 rounded-xl font-semibold text-sm btn-primary-gradient">
              Confirmar Transferência
            </button>
          </div>
        ) : (
          <div className="text-center py-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} className="text-emerald-400" />
            </div>
            <h3 className="text-lg font-bold mb-2" style={{ color: "rgba(255,255,255,0.9)" }}>Transferência realizada!</h3>
            <p className="text-sm mb-1" style={{ color: "rgba(255,255,255,0.5)" }}>
              {fmtBRL(parseFloat(amount))} enviado para <strong style={{ color: "rgba(255,255,255,0.8)" }}>{dest}</strong>
            </p>
            <p className="text-xs mb-6" style={{ color: "rgba(255,255,255,0.3)" }}>Protocolo: FOP{Date.now()}</p>
            <button onClick={handleClose} className="px-6 py-2.5 rounded-xl text-sm btn-primary-gradient">Fechar</button>
          </div>
        )}
      </div>
    </Modal>
  );
}

// ─── Pagar Modal ──────────────────────────────────────────────────────────────
function PagarModal({ open, onClose, accounts, onPay }: {
  open: boolean; onClose: () => void;
  accounts: Account[];
  onPay: (fromId: string, amount: number, cat: string, desc: string) => void;
}) {
  const [step, setStep] = useState<"type" | "form" | "success">("type");
  const [type, setType] = useState<"boleto" | "conta" | "cartao" | "pix">("boleto");
  const [fromId, setFromId] = useState("1");
  const [barcode, setBarcode] = useState("");
  const [pixKey, setPixKey] = useState("");
  const [amount, setAmount] = useState("");
  const [receiver, setReceiver] = useState("");
  const [cardPayType, setCardPayType] = useState<"min" | "total" | "custom">("total");
  const [protocol, setProtocol] = useState("");

  const autoFill = (val: string) => {
    if (val.length >= 10) {
      setReceiver("Empresa Exemplo S.A.");
      setAmount("347.80");
    }
  };

  const autoFillPix = (val: string) => {
    if (val.length >= 5) setReceiver("João da Silva");
  };

  const getAmount = () => {
    if (type === "cartao") {
      if (cardPayType === "min") return 150;
      if (cardPayType === "total") return 1240;
      return parseFloat(amount) || 0;
    }
    return parseFloat(amount) || 0;
  };

  const getCat = () => {
    const map = { boleto: "Boleto", conta: "Utilidades", cartao: "Cartão Crédito", pix: "PIX" };
    return map[type];
  };

  const getDesc = () => {
    const map = {
      boleto: `Boleto — ${receiver || "Beneficiário"}`,
      conta: `Conta de Utilidade — ${receiver || "Beneficiário"}`,
      cartao: "Fatura Cartão de Crédito",
      pix: `PIX para ${receiver || pixKey}`,
    };
    return map[type];
  };

  const handleConfirm = () => {
    const amt = getAmount();
    const from = accounts.find((a) => a.id === fromId);
    if (!from || from.balance < amt) { toast.error("Saldo insuficiente"); return; }
    const proto = `FOP${Date.now()}`;
    setProtocol(proto);
    onPay(fromId, amt, getCat(), getDesc());
    setStep("success");
  };

  const handleClose = () => {
    setStep("type"); setBarcode(""); setPixKey(""); setAmount(""); setReceiver("");
    onClose();
  };

  const types = [
    { id: "boleto", icon: <FileText size={20} />, label: "Boleto Bancário" },
    { id: "conta", icon: <Zap size={20} />, label: "Conta de Luz/Água/Gás" },
    { id: "cartao", icon: <CreditCard size={20} />, label: "Cartão de Crédito" },
    { id: "pix", icon: <ArrowRightLeft size={20} />, label: "PIX" },
  ] as const;

  return (
    <Modal open={open} onClose={handleClose}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>
            {step === "type" ? "Pagar" : step === "form" ? `Pagar ${types.find(t => t.id === type)?.label}` : "Pagamento Realizado"}
          </h2>
          <button onClick={handleClose}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
        </div>

        {step === "type" && (
          <div className="grid grid-cols-2 gap-3">
            {types.map((t) => (
              <button
                key={t.id}
                onClick={() => { setType(t.id); setStep("form"); }}
                className="flex flex-col items-center gap-2 p-4 rounded-xl transition-all hover:bg-white/5 card-hover"
                style={{ border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.7)" }}
              >
                <span className="text-indigo-400">{t.icon}</span>
                <span className="text-xs font-medium text-center">{t.label}</span>
              </button>
            ))}
          </div>
        )}

        {step === "form" && (
          <div className="space-y-4">
            {(type === "boleto" || type === "conta") && (
              <>
                <div>
                  <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>
                    {type === "boleto" ? "Código de barras (48 dígitos)" : "Código de barras / Número da conta"}
                  </label>
                  <input
                    value={barcode}
                    onChange={(e) => { setBarcode(e.target.value); autoFill(e.target.value); }}
                    placeholder="00000.00000 00000.000000..."
                    className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
                  />
                </div>
                {receiver && (
                  <div className="p-3 rounded-xl space-y-1" style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)" }}>
                    <div className="flex justify-between text-xs">
                      <span style={{ color: "rgba(255,255,255,0.5)" }}>Beneficiário</span>
                      <span style={{ color: "rgba(255,255,255,0.9)" }}>{receiver}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span style={{ color: "rgba(255,255,255,0.5)" }}>Valor</span>
                      <span className="font-mono-finance text-emerald-400">{fmtBRL(parseFloat(amount))}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span style={{ color: "rgba(255,255,255,0.5)" }}>Vencimento</span>
                      <span style={{ color: "rgba(255,255,255,0.9)" }}>{fmtDate(new Date(Date.now() + 86400000))}</span>
                    </div>
                  </div>
                )}
              </>
            )}

            {type === "cartao" && (
              <div className="space-y-3">
                <p className="text-sm" style={{ color: "rgba(255,255,255,0.6)" }}>Fatura do Cartão FinOpsHub Visa</p>
                {[
                  { id: "min", label: "Mínimo", value: "R$ 150,00" },
                  { id: "total", label: "Total", value: "R$ 1.240,00" },
                  { id: "custom", label: "Outro valor", value: "" },
                ].map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => setCardPayType(opt.id as any)}
                    className="w-full flex items-center justify-between px-4 py-3 rounded-xl text-sm transition-all"
                    style={{
                      background: cardPayType === opt.id ? "rgba(99,102,241,0.15)" : "rgba(255,255,255,0.03)",
                      border: `1px solid ${cardPayType === opt.id ? "rgba(99,102,241,0.4)" : "rgba(255,255,255,0.08)"}`,
                      color: "rgba(255,255,255,0.8)",
                    }}
                  >
                    <span>{opt.label}</span>
                    {opt.value && <span className="font-mono-finance text-emerald-400">{opt.value}</span>}
                  </button>
                ))}
                {cardPayType === "custom" && (
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="Valor personalizado"
                    className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
                  />
                )}
              </div>
            )}

            {type === "pix" && (
              <>
                <div>
                  <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Chave PIX (CPF, email, telefone)</label>
                  <input
                    value={pixKey}
                    onChange={(e) => { setPixKey(e.target.value); autoFillPix(e.target.value); }}
                    placeholder="Ex: 123.456.789-00"
                    className="w-full px-3 py-2.5 rounded-xl text-sm"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
                  />
                </div>
                {receiver && (
                  <div className="p-2 rounded-lg text-xs" style={{ background: "rgba(16,185,129,0.1)", color: "#10b981" }}>
                    ✓ Recebedor: {receiver}
                  </div>
                )}
                <div>
                  <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Valor</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0,00"
                    className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
                  />
                </div>
              </>
            )}

            {/* Source account */}
            <div>
              <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Conta de origem</label>
              <select
                value={fromId}
                onChange={(e) => setFromId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl text-sm"
                style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
              >
                {accounts.map((a) => (
                  <option key={a.id} value={a.id} style={{ background: "#13102b" }}>
                    {a.icon} {a.bank} — {fmtBRL(a.balance)}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep("type")} className="flex-1 py-2.5 rounded-xl text-sm" style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}>
                Voltar
              </button>
              <button onClick={handleConfirm} className="flex-1 py-2.5 rounded-xl text-sm font-semibold btn-primary-gradient">
                Confirmar
              </button>
            </div>
          </div>
        )}

        {step === "success" && (
          <div className="text-center py-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} className="text-emerald-400" />
            </div>
            <h3 className="text-lg font-bold mb-2" style={{ color: "rgba(255,255,255,0.9)" }}>Pagamento realizado!</h3>
            <p className="text-sm mb-1" style={{ color: "rgba(255,255,255,0.5)" }}>{getDesc()}</p>
            <p className="text-xl font-bold font-mono-finance text-emerald-400 mb-1">{fmtBRL(getAmount())}</p>
            <p className="text-xs mb-2" style={{ color: "rgba(255,255,255,0.3)" }}>Protocolo: {protocol}</p>
            <button
              onClick={() => { toast.info(`Comprovante ${protocol} gerado`); }}
              className="px-4 py-2 rounded-lg text-xs mr-2"
              style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}
            >
              Comprovante
            </button>
            <button onClick={handleClose} className="px-6 py-2 rounded-xl text-sm btn-primary-gradient">Fechar</button>
          </div>
        )}
      </div>
    </Modal>
  );
}

// ─── Depositar Modal ──────────────────────────────────────────────────────────
function DepositarModal({ open, onClose, accounts, onDeposit }: {
  open: boolean; onClose: () => void;
  accounts: Account[];
  onDeposit: (toId: string, amount: number, desc: string) => void;
}) {
  const [tab, setTab] = useState<"pix" | "ted">("pix");
  const [toId, setToId] = useState("1");
  const [amount, setAmount] = useState("");
  const [qrGenerated, setQrGenerated] = useState(false);
  const [step, setStep] = useState<"form" | "success">("form");
  const [successMsg, setSuccessMsg] = useState("");

  const pixKey = `finopshub.${toId}@pix.com`;
  const bankDetails = `Banco: 260 — Nu Pagamentos\nAgência: 0001\nConta: 12345-6\nCNPJ: 12.345.678/0001-95\nFavorecido: FinOpsHub Tecnologia Ltda`;

  const handleSimulateReceive = (type: "pix" | "ted") => {
    const amt = parseFloat(amount);
    if (!amt || amt <= 0) { toast.error("Informe um valor"); return; }
    const desc = type === "pix" ? "Depósito via PIX" : "Depósito TED";
    onDeposit(toId, amt, desc);
    setSuccessMsg(`${fmtBRL(amt)} adicionado à conta ${accounts.find(a => a.id === toId)?.bank}`);
    setStep("success");
  };

  const handleClose = () => { setStep("form"); setAmount(""); setQrGenerated(false); onClose(); };

  return (
    <Modal open={open} onClose={handleClose}>
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Depositar</h2>
          <button onClick={handleClose}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
        </div>

        {step === "form" ? (
          <>
            <div className="flex gap-2 mb-4">
              {(["pix", "ted"] as const).map((t) => (
                <button
                  key={t}
                  onClick={() => setTab(t)}
                  className="flex-1 py-2 rounded-xl text-sm font-medium transition-all"
                  style={{
                    background: tab === t ? "rgba(99,102,241,0.2)" : "rgba(255,255,255,0.03)",
                    border: `1px solid ${tab === t ? "rgba(99,102,241,0.4)" : "rgba(255,255,255,0.08)"}`,
                    color: tab === t ? "#818cf8" : "rgba(255,255,255,0.5)",
                  }}
                >
                  {t === "pix" ? "PIX" : "TED / DOC"}
                </button>
              ))}
            </div>

            {tab === "pix" && (
              <div className="space-y-4">
                <div>
                  <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Conta destino</label>
                  <select
                    value={toId}
                    onChange={(e) => { setToId(e.target.value); setQrGenerated(false); }}
                    className="w-full px-3 py-2.5 rounded-xl text-sm"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
                  >
                    {accounts.map((a) => (
                      <option key={a.id} value={a.id} style={{ background: "#13102b" }}>{a.icon} {a.bank}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Valor</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => { setAmount(e.target.value); setQrGenerated(false); }}
                    placeholder="0,00"
                    className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
                  />
                </div>
                <button
                  onClick={() => setQrGenerated(true)}
                  className="w-full py-2.5 rounded-xl text-sm font-semibold btn-primary-gradient"
                >
                  Gerar QR Code PIX
                </button>
                {qrGenerated && (
                  <div className="flex flex-col items-center gap-3 p-4 rounded-xl" style={{ background: "rgba(255,255,255,0.03)" }}>
                    <QRCodeSVG seed={`${toId}-${amount}-${Date.now()}`} size={160} />
                    <p className="text-xs font-mono-finance text-indigo-400">{pixKey}</p>
                    <button
                      onClick={() => { navigator.clipboard.writeText(pixKey); toast.success("Chave copiada!"); }}
                      className="flex items-center gap-2 px-4 py-2 rounded-lg text-xs"
                      style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}
                    >
                      <Copy size={12} /> Copiar chave PIX
                    </button>
                    <button
                      onClick={() => handleSimulateReceive("pix")}
                      className="w-full py-2.5 rounded-xl text-sm font-semibold"
                      style={{ background: "rgba(16,185,129,0.2)", border: "1px solid rgba(16,185,129,0.3)", color: "#10b981" }}
                    >
                      Simular recebimento
                    </button>
                  </div>
                )}
              </div>
            )}

            {tab === "ted" && (
              <div className="space-y-4">
                <div className="p-4 rounded-xl space-y-2" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)" }}>
                  {[
                    ["Banco", "260 — Nu Pagamentos"],
                    ["Agência", "0001"],
                    ["Conta", "12345-6"],
                    ["CNPJ", "12.345.678/0001-95"],
                    ["Favorecido", "FinOpsHub Tecnologia Ltda"],
                  ].map(([k, v]) => (
                    <div key={k} className="flex justify-between text-xs">
                      <span style={{ color: "rgba(255,255,255,0.4)" }}>{k}</span>
                      <span className="font-mono-finance" style={{ color: "rgba(255,255,255,0.9)" }}>{v}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={() => { navigator.clipboard.writeText(bankDetails); toast.success("Dados copiados!"); }}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-sm"
                  style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}
                >
                  <Copy size={14} /> Copiar dados bancários
                </button>
                <div>
                  <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Valor</label>
                  <input
                    type="number"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="0,00"
                    className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance"
                    style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }}
                  />
                </div>
                <button
                  onClick={() => handleSimulateReceive("ted")}
                  className="w-full py-2.5 rounded-xl text-sm font-semibold"
                  style={{ background: "rgba(16,185,129,0.2)", border: "1px solid rgba(16,185,129,0.3)", color: "#10b981" }}
                >
                  Simular TED recebida
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="text-center py-6">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} className="text-emerald-400" />
            </div>
            <h3 className="text-lg font-bold mb-2 text-emerald-400">Depósito recebido!</h3>
            <p className="text-sm mb-6" style={{ color: "rgba(255,255,255,0.6)" }}>{successMsg}</p>
            <button onClick={handleClose} className="px-6 py-2.5 rounded-xl text-sm btn-primary-gradient">Fechar</button>
          </div>
        )}
      </div>
    </Modal>
  );
}

// ─── Finance Dashboard ────────────────────────────────────────────────────────
function FinanceDashboard({
  accounts, transactions, batches, balVis, setView,
  onTransfer, onPay, onDeposit,
}: {
  accounts: Account[];
  transactions: Transaction[];
  batches: PayrollBatch[];
  balVis: boolean;
  setView: (v: string) => void;
  onTransfer: (fromId: string, amount: number, dest: string) => void;
  onPay: (fromId: string, amount: number, cat: string, desc: string) => void;
  onDeposit: (toId: string, amount: number, desc: string) => void;
}) {
  const [transferOpen, setTransferOpen] = useState(false);
  const [pagarOpen, setPagarOpen] = useState(false);
  const [depositarOpen, setDepositarOpen] = useState(false);

  const totalPatrimonio = accounts.reduce((s, a) => s + a.balance, 0);

  // Cash flow last 7 days
  const cashFlow = useMemo(() => {
    const days: { day: string; entrada: number; saida: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const dt = d(i);
      const dayStr = dt.toLocaleDateString("pt-BR", { weekday: "short" });
      const entrada = transactions
        .filter((t) => t.type === "income" && t.date.toDateString() === dt.toDateString())
        .reduce((s, t) => s + t.amount, 0);
      const saida = transactions
        .filter((t) => t.type === "expense" && t.date.toDateString() === dt.toDateString())
        .reduce((s, t) => s + t.amount, 0);
      days.push({ day: dayStr, entrada, saida });
    }
    return days;
  }, [transactions]);

  const recentTxs = transactions.slice(0, 6);
  const latestBatch = batches[0];

  const sparkData = [24000, 25100, 24800, 26200, 25900, 27100, totalPatrimonio / 1000];

  return (
    <div className="space-y-6">
      {/* Hero card */}
      <div
        className="rounded-2xl p-6 relative overflow-hidden"
        style={{
          background: "linear-gradient(135deg, rgba(99,102,241,0.2) 0%, rgba(153,69,255,0.15) 100%)",
          border: "1px solid rgba(99,102,241,0.3)",
        }}
      >
        <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(ellipse at 80% 50%, #6366f1 0%, transparent 60%)" }} />
        <div className="relative">
          <p className="text-xs font-medium mb-1" style={{ color: "rgba(255,255,255,0.5)" }}>Patrimônio Total</p>
          <div className="text-4xl font-bold font-mono-finance mb-1" style={{ color: "rgba(255,255,255,0.95)" }}>
            {balVis ? (
              <AnimatedCounter value={totalPatrimonio} prefix="R$ " />
            ) : (
              <span>R$ •••••</span>
            )}
          </div>
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
            {accounts.length} contas ativas • Atualizado agora
          </p>
        </div>
        <div className="absolute right-6 top-6 opacity-30">
          <MiniSparkline data={sparkData} color="#818cf8" />
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-5 gap-2">
        {[
          { icon: <ArrowRightLeft size={18} />, label: "Transferir", action: () => setTransferOpen(true), color: "#6366f1" },
          { icon: <Receipt size={18} />, label: "Pagar", action: () => setPagarOpen(true), color: "#f59e0b" },
          { icon: <Download size={18} />, label: "Depositar", action: () => setDepositarOpen(true), color: "#10b981" },
          { icon: <Users size={18} />, label: "Folha", action: () => {}, color: "#818cf8" },
          { icon: <Wallet size={18} />, label: "Crypto", action: () => setView("crypto"), color: "#9945FF" },
        ].map((btn) => (
          <button
            key={btn.label}
            onClick={btn.action}
            className="flex flex-col items-center gap-2 py-3 rounded-xl transition-all hover:bg-white/5 card-hover"
            style={{ border: "1px solid rgba(255,255,255,0.06)" }}
          >
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: `${btn.color}20`, color: btn.color }}
            >
              {btn.icon}
            </div>
            <span className="text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>{btn.label}</span>
          </button>
        ))}
      </div>

      {/* Charts + accounts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Cash flow chart */}
        <div className="lg:col-span-2 glass-card p-4">
          <h3 className="text-sm font-semibold mb-4" style={{ color: "rgba(255,255,255,0.7)" }}>Fluxo de Caixa — 7 dias</h3>
          <ResponsiveContainer width="100%" height={180}>
            <BarChart data={cashFlow} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="day" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: "rgba(13,11,29,0.95)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }}
                formatter={(v: number) => fmtBRL(v)}
              />
              <Bar dataKey="entrada" fill="#10b981" radius={[4, 4, 0, 0]} name="Entrada" />
              <Bar dataKey="saida" fill="#ef4444" radius={[4, 4, 0, 0]} name="Saída" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Account cards */}
        <div className="space-y-2">
          {accounts.map((acc) => (
            <div key={acc.id} className="glass-card p-3 flex items-center justify-between card-hover">
              <div className="flex items-center gap-2">
                <span className="text-lg">{acc.icon}</span>
                <div>
                  <p className="text-xs font-semibold" style={{ color: "rgba(255,255,255,0.8)" }}>{acc.bank}</p>
                  <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>{acc.type}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold font-mono-finance" style={{ color: "rgba(255,255,255,0.9)" }}>
                  {balVis ? fmtBRL(acc.balance) : "•••"}
                </p>
                <MiniSparkline data={[acc.balance * 0.9, acc.balance * 0.95, acc.balance * 0.92, acc.balance]} color="#6366f1" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recent transactions */}
      <div className="glass-card p-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.7)" }}>Transações Recentes</h3>
          <button onClick={() => setView("extrato")} className="text-xs text-indigo-400 hover:text-indigo-300">Ver todas</button>
        </div>
        <div className="space-y-2">
          {recentTxs.map((tx) => (
            <div key={tx.id} className="flex items-center gap-3 py-2">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center text-sm shrink-0"
                style={{ background: tx.type === "income" ? "rgba(16,185,129,0.15)" : "rgba(239,68,68,0.15)" }}
              >
                <CatIcon cat={tx.cat} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate" style={{ color: "rgba(255,255,255,0.85)" }}>{tx.desc}</p>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>{fmtDate(tx.date)} • {tx.cat}</p>
              </div>
              <span
                className="text-sm font-bold font-mono-finance shrink-0"
                style={{ color: tx.type === "income" ? "#10b981" : "#ef4444" }}
              >
                {tx.type === "income" ? "+" : "-"}{balVis ? fmtBRL(tx.amount) : "•••"}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Payroll insight */}
      {latestBatch && (
        <div
          className="rounded-xl p-4 flex items-center justify-between"
          style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)" }}
        >
          <div>
            <p className="text-xs font-semibold text-indigo-400">Folha {fmtMonth(latestBatch.month)}</p>
            <p className="text-sm font-bold font-mono-finance" style={{ color: "rgba(255,255,255,0.9)" }}>
              {balVis ? fmtBRL(latestBatch.totalNet) : "•••"} líquido
            </p>
            <StatusBadge status={latestBatch.status} />
          </div>
          <button
            onClick={() => {}}
            className="px-4 py-2 rounded-xl text-xs font-semibold btn-primary-gradient"
          >
            Ver Folha
          </button>
        </div>
      )}

      {/* Modals */}
      <TransferModal open={transferOpen} onClose={() => setTransferOpen(false)} accounts={accounts} onTransfer={onTransfer} />
      <PagarModal open={pagarOpen} onClose={() => setPagarOpen(false)} accounts={accounts} onPay={onPay} />
      <DepositarModal open={depositarOpen} onClose={() => setDepositarOpen(false)} accounts={accounts} onDeposit={onDeposit} />
    </div>
  );
}

// ─── Contas View ──────────────────────────────────────────────────────────────
function ContasView({ accounts, balVis, onTransfer }: {
  accounts: Account[]; balVis: boolean;
  onTransfer: (fromId: string, amount: number, dest: string) => void;
}) {
  const [transferOpen, setTransferOpen] = useState(false);
  const [selectedId, setSelectedId] = useState("1");

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Contas</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {accounts.map((acc) => (
          <div
            key={acc.id}
            className={`rounded-2xl p-5 bg-gradient-to-br ${acc.gradient} relative overflow-hidden card-hover`}
          >
            <div className="absolute inset-0 opacity-20" style={{ background: "radial-gradient(ellipse at 80% 20%, white 0%, transparent 60%)" }} />
            <div className="relative">
              <div className="flex items-center justify-between mb-4">
                <span className="text-2xl">{acc.icon}</span>
                <span className="text-xs font-medium px-2 py-1 rounded-full bg-white/20 text-white">{acc.type}</span>
              </div>
              <p className="text-sm font-medium text-white/80">{acc.bank}</p>
              <p className="text-2xl font-bold font-mono-finance text-white mt-1">
                {balVis ? fmtBRL(acc.balance) : "R$ •••••"}
              </p>
              <button
                onClick={() => { setSelectedId(acc.id); setTransferOpen(true); }}
                className="mt-4 px-4 py-1.5 rounded-xl text-xs font-semibold bg-white/20 text-white hover:bg-white/30 transition-all"
              >
                Transferir
              </button>
            </div>
          </div>
        ))}
      </div>
      <TransferModal
        open={transferOpen}
        onClose={() => setTransferOpen(false)}
        accounts={accounts}
        onTransfer={onTransfer}
      />
    </div>
  );
}

// ─── Extrato View ─────────────────────────────────────────────────────────────
function ExtratoView({ transactions, accounts, balVis }: {
  transactions: Transaction[]; accounts: Account[]; balVis: boolean;
}) {
  const [filter, setFilter] = useState<"all" | "income" | "expense">("all");
  const filtered = filter === "all" ? transactions : transactions.filter((t) => t.type === filter);
  const getBank = (id: string) => accounts.find((a) => a.id === id)?.bank || "";

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Extrato</h2>
        <div className="flex gap-2">
          {(["all", "income", "expense"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className="px-3 py-1.5 rounded-xl text-xs font-medium transition-all"
              style={{
                background: filter === f ? "rgba(99,102,241,0.2)" : "rgba(255,255,255,0.03)",
                border: `1px solid ${filter === f ? "rgba(99,102,241,0.4)" : "rgba(255,255,255,0.08)"}`,
                color: filter === f ? "#818cf8" : "rgba(255,255,255,0.5)",
              }}
            >
              {f === "all" ? "Todos" : f === "income" ? "Entradas" : "Saídas"}
            </button>
          ))}
        </div>
      </div>
      <div className="glass-card divide-y" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
        {filtered.map((tx) => (
          <div key={tx.id} className="flex items-center gap-3 p-4">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center text-base shrink-0"
              style={{ background: tx.type === "income" ? "rgba(16,185,129,0.15)" : "rgba(239,68,68,0.15)" }}
            >
              <CatIcon cat={tx.cat} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium" style={{ color: "rgba(255,255,255,0.85)" }}>{tx.desc}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>{fmtDate(tx.date)}</span>
                <span
                  className="text-xs px-2 py-0.5 rounded-full"
                  style={{ background: "rgba(99,102,241,0.1)", color: "#818cf8" }}
                >
                  {tx.cat}
                </span>
                <span className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>{getBank(tx.bankId)}</span>
              </div>
            </div>
            <span
              className="text-sm font-bold font-mono-finance shrink-0"
              style={{ color: tx.type === "income" ? "#10b981" : "#ef4444" }}
            >
              {tx.type === "income" ? "+" : "-"}{balVis ? fmtBRL(tx.amount) : "•••"}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Cartões View ─────────────────────────────────────────────────────────────
function CartoesView({ balVis, setView }: { balVis: boolean; setView: (v: string) => void }) {
  const cards = [
    { id: "c1", name: "FinOpsHub Visa Platinum", number: "•••• •••• •••• 4521", limit: 15000, used: 1240, gradient: "from-indigo-600 to-violet-800", bank: "Nubank" },
    { id: "c2", name: "Itaú Personnalité", number: "•••• •••• •••• 7834", limit: 25000, used: 3420, gradient: "from-amber-500 to-orange-700", bank: "Itaú" },
    { id: "c3", name: "XP Investimentos Black", number: "•••• •••• •••• 2190", limit: 30000, used: 890, gradient: "from-emerald-600 to-teal-800", bank: "XP" },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Cartões</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {cards.map((card) => (
          <div key={card.id} className={`rounded-2xl p-5 bg-gradient-to-br ${card.gradient} relative overflow-hidden card-hover`}>
            <div className="absolute inset-0 opacity-10" style={{ background: "radial-gradient(ellipse at 80% 20%, white 0%, transparent 60%)" }} />
            <div className="relative">
              <div className="flex items-center justify-between mb-8">
                <span className="text-xs font-medium text-white/70">{card.bank}</span>
                <div className="flex gap-1">
                  <div className="w-6 h-6 rounded-full bg-red-500 opacity-90" />
                  <div className="w-6 h-6 rounded-full bg-yellow-400 opacity-90 -ml-2" />
                </div>
              </div>
              <p className="font-mono-finance text-sm text-white/90 mb-3">{card.number}</p>
              <p className="text-xs text-white/70 font-medium">{card.name}</p>
              <div className="mt-3">
                <div className="flex justify-between text-xs text-white/60 mb-1">
                  <span>Limite usado</span>
                  <span>{balVis ? `${fmtBRL(card.used)} / ${fmtBRL(card.limit)}` : "•••"}</span>
                </div>
                <div className="h-1.5 rounded-full bg-white/20">
                  <div
                    className="h-full rounded-full bg-white/70"
                    style={{ width: `${(card.used / card.limit) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <button
        onClick={() => setView("crypto")}
        className="flex items-center gap-2 px-4 py-3 rounded-xl text-sm font-medium transition-all"
        style={{
          background: "rgba(153,69,255,0.1)",
          border: "1px solid rgba(153,69,255,0.3)",
          color: "#9945FF",
        }}
      >
        <span className="text-lg">◎</span>
        Ver Cartão Crypto Virtual
        <ArrowUpRight size={14} />
      </button>
    </div>
  );
}

// ─── Crypto / Solana View ─────────────────────────────────────────────────────
function CryptoView({ authToken, balVis }: { authToken: string; balVis: boolean }) {
  const userId = authToken.startsWith("local_") ? authToken.replace("local_", "") : authToken;
  const [subTab, setSubTab] = useState<"carteira" | "cartao">("carteira");
  const [wallet, setWallet] = useState<SolanaWallet | null>(null);
  const [card, setCard] = useState<VirtualCard | null>(null);
  const [cardTxs, setCardTxs] = useState<CardTx[]>([]);
  const [loading, setLoading] = useState(false);
  const [phantomModal, setPhantomModal] = useState(false);
  const [createModal, setCreateModal] = useState(false);
  const [sendModal, setSendModal] = useState(false);
  const [receiveModal, setReceiveModal] = useState(false);
  const [fundModal, setFundModal] = useState(false);
  const [purchaseModal, setPurchaseModal] = useState(false);
  const [cardFlipped, setCardFlipped] = useState(false);
  const [cvvVisible, setCvvVisible] = useState(false);
  const [sendDest, setSendDest] = useState("");
  const [sendAmount, setSendAmount] = useState("");
  const [fundAmount, setFundAmount] = useState("");
  const [purchaseMerchant, setPurchaseMerchant] = useState("");
  const [purchaseAmount, setPurchaseAmount] = useState("");

  // tRPC mutations
  const connectMut = trpc.wallet.connect.useMutation();
  const createWalletMut = trpc.wallet.create.useMutation();
  const airdropMut = trpc.wallet.airdrop.useMutation();
  const sendMut = trpc.wallet.send.useMutation();
  const disconnectMut = trpc.wallet.disconnect.useMutation();
  const createCardMut = trpc.card.create.useMutation();
  const fundCardMut = trpc.card.fund.useMutation();
  const toggleStatusMut = trpc.card.toggleStatus.useMutation();
  const purchaseMut = trpc.card.purchase.useMutation();

  // Load wallet and card from tRPC
  const walletQuery = trpc.wallet.get.useQuery({ userId }, { enabled: !!userId });
  const cardQuery = trpc.card.get.useQuery({ userId }, { enabled: !!userId });
  const cardTxsQuery = trpc.card.getTxs.useQuery({ userId }, { enabled: !!userId });

  useEffect(() => {
    if (walletQuery.data) setWallet(walletQuery.data as SolanaWallet);
  }, [walletQuery.data]);

  useEffect(() => {
    if (cardQuery.data) setCard(cardQuery.data as VirtualCard);
  }, [cardQuery.data]);

  useEffect(() => {
    if (cardTxsQuery.data) setCardTxs(cardTxsQuery.data as CardTx[]);
  }, [cardTxsQuery.data]);

  const connectPhantom = async () => {
    setLoading(true);
    try {
      const data = await connectMut.mutateAsync({ userId });
      setWallet(data.wallet as SolanaWallet);
      setPhantomModal(false);
      toast.success("Carteira Phantom conectada!");
    } catch { toast.error("Erro ao conectar carteira"); }
    setLoading(false);
  };

  const createWallet = async () => {
    setLoading(true);
    try {
      const data = await createWalletMut.mutateAsync({ userId });
      setWallet(data.wallet as SolanaWallet);
      setCreateModal(false);
      toast.success("Carteira criada na Solana devnet!");
    } catch (e: any) { toast.error(e.message || "Erro ao criar carteira"); }
    setLoading(false);
  };

  const requestAirdrop = async () => {
    setLoading(true);
    try {
      const data = await airdropMut.mutateAsync({ userId });
      if (data.wallet) setWallet(data.wallet as SolanaWallet);
      toast.success(`1 SOL + 10 USDC recebidos! TX: ${data.txHash.slice(0, 12)}...`);
    } catch { toast.error("Erro no airdrop"); }
    setLoading(false);
  };

  const sendSOL = async () => {
    if (!sendDest || !sendAmount) { toast.error("Preencha todos os campos"); return; }
    setLoading(true);
    try {
      const data = await sendMut.mutateAsync({ userId, destination: sendDest, amount: parseFloat(sendAmount) });
      setWallet(data.wallet as SolanaWallet);
      setSendModal(false);
      toast.success(`SOL enviado! TX: ${data.txHash.slice(0, 12)}...`);
    } catch (e: any) { toast.error(e.message); }
    setLoading(false);
  };

  const disconnectWallet = async () => {
    try {
      await disconnectMut.mutateAsync({ userId });
      setWallet(null);
      toast.info("Carteira desconectada");
    } catch {}
  };

  const createCard = async () => {
    setLoading(true);
    try {
      const userStr = localStorage.getItem("finopshub_user");
      const user = userStr ? JSON.parse(userStr) : { name: "User" };
      const data = await createCardMut.mutateAsync({ userId, holderName: user.name });
      setCard(data.card as VirtualCard);
      setCardTxs([]);
      toast.success("Cartão virtual criado!");
    } catch (e: any) { toast.error(e.message || "Erro ao criar cartão"); }
    setLoading(false);
  };

  const fundCard = async () => {
    const amt = parseFloat(fundAmount);
    if (!amt) { toast.error("Informe um valor"); return; }
    setLoading(true);
    try {
      const data = await fundCardMut.mutateAsync({ userId, usdcAmount: amt });
      setCard(data.card as VirtualCard);
      setWallet(data.wallet as SolanaWallet);
      setFundModal(false);
      toast.success(`Cartão carregado com ${amt} USDC`);
    } catch (e: any) { toast.error(e.message); }
    setLoading(false);
  };

  const toggleCardStatus = async () => {
    if (!card) return;
    try {
      const data = await toggleStatusMut.mutateAsync({ userId });
      setCard(data.card as VirtualCard);
      toast.info(data.card.status === "blocked" ? "Cartão bloqueado" : "Cartão desbloqueado");
    } catch {}
  };

  const simulatePurchase = async () => {
    if (!purchaseMerchant || !purchaseAmount) { toast.error("Preencha todos os campos"); return; }
    setLoading(true);
    try {
      const data = await purchaseMut.mutateAsync({ userId, merchant: purchaseMerchant, amountBRL: parseFloat(purchaseAmount) });
      setCard(data.card as VirtualCard);
      const newTx = data.tx as CardTx;
      setCardTxs((prev) => [newTx, ...prev]);
      setPurchaseModal(false);
      toast.success(`Compra em ${purchaseMerchant} realizada!`);
    } catch (e: any) { toast.error(e.message); }
    setLoading(false);
  };

    const mockWalletTxs = [
    { id: "wt1", type: "received", desc: "SOL recebido", amount: "+1.5 SOL", date: fmtDate(d(1)), color: "#10b981" },
    { id: "wt2", type: "sent", desc: "SOL enviado", amount: "-0.25 SOL", date: fmtDate(d(3)), color: "#ef4444" },
    { id: "wt3", type: "received", desc: "USDC recebido", amount: "+500 USDC", date: fmtDate(d(5)), color: "#10b981" },
    { id: "wt4", type: "airdrop", desc: "Airdrop devnet", amount: "+0.5 SOL", date: fmtDate(d(7)), color: "#9945FF" },
    { id: "wt5", type: "sent", desc: "Transferência SOL", amount: "-0.1 SOL", date: fmtDate(d(9)), color: "#ef4444" },
  ];

  return (
    <div className="space-y-4">
      {/* Sub-tabs */}
      <div className="flex gap-2">
        {(["carteira", "cartao"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setSubTab(t)}
            className="px-4 py-2 rounded-xl text-sm font-medium transition-all"
            style={{
              background: subTab === t ? "rgba(153,69,255,0.2)" : "rgba(255,255,255,0.03)",
              border: `1px solid ${subTab === t ? "rgba(153,69,255,0.4)" : "rgba(255,255,255,0.08)"}`,
              color: subTab === t ? "#9945FF" : "rgba(255,255,255,0.5)",
            }}
          >
            {t === "carteira" ? "◎ Carteira Solana" : "💳 Cartão Virtual"}
          </button>
        ))}
      </div>

      {/* ── Carteira ── */}
      {subTab === "carteira" && (
        <>
          {!wallet ? (
            <div className="glass-card p-8 text-center">
              <div className="text-6xl font-bold mb-4" style={{ color: "#9945FF" }}>◎</div>
              <h3 className="text-xl font-bold mb-2" style={{ color: "rgba(255,255,255,0.9)" }}>Conectar Carteira Solana</h3>
              <p className="text-sm mb-6 max-w-sm mx-auto" style={{ color: "rgba(255,255,255,0.5)" }}>
                Adicione sua carteira para visualizar saldo SOL, enviar e receber tokens diretamente no FinOpsHub.
              </p>
              <div className="flex gap-3 justify-center">
                <button
                  onClick={() => setPhantomModal(true)}
                  className="px-5 py-2.5 rounded-xl text-sm font-semibold"
                  style={{ background: "rgba(153,69,255,0.2)", border: "1px solid rgba(153,69,255,0.4)", color: "#9945FF" }}
                >
                  Conectar Phantom
                </button>
                <button
                  onClick={() => setCreateModal(true)}
                  className="px-5 py-2.5 rounded-xl text-sm font-semibold btn-primary-gradient"
                >
                  Criar Nova Carteira
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {/* Left */}
              <div className="space-y-4">
                {/* Wallet hero */}
                <div
                  className="rounded-2xl p-5"
                  style={{ background: "linear-gradient(135deg, rgba(153,69,255,0.25) 0%, rgba(20,241,149,0.1) 100%)", border: "1px solid rgba(153,69,255,0.3)" }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl">◎</span>
                      <span className="text-sm font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Carteira Solana</span>
                    </div>
                    <span className="text-xs px-2 py-1 rounded-full" style={{ background: "rgba(20,241,149,0.15)", color: "#14F195" }}>
                      devnet
                    </span>
                  </div>
                  <div className="flex items-center gap-2 mb-4">
                    <span className="font-mono-finance text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>
                      {truncateKey(wallet.publicKey)}
                    </span>
                    <button onClick={() => { navigator.clipboard.writeText(wallet.publicKey); toast.success("Endereço copiado!"); }}>
                      <Copy size={12} style={{ color: "rgba(255,255,255,0.4)" }} />
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.05)" }}>
                      <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>SOL</p>
                      <p className="text-xl font-bold font-mono-finance" style={{ color: "#9945FF" }}>
                        {balVis ? wallet.solBalance.toFixed(4) : "•••"}
                      </p>
                      <p className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
                        ≈ {balVis ? fmtBRL(wallet.solBalance * 150 * 5) : "•••"}
                      </p>
                    </div>
                    <div className="p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.05)" }}>
                      <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>USDC</p>
                      <p className="text-xl font-bold font-mono-finance" style={{ color: "#14F195" }}>
                        {balVis ? wallet.usdcBalance.toFixed(2) : "•••"}
                      </p>
                      <p className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>
                        ≈ {balVis ? fmtBRL(wallet.usdcBalance * 5) : "•••"}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Quick actions */}
                <div className="grid grid-cols-3 gap-2">
                  <button onClick={() => setSendModal(true)} className="flex flex-col items-center gap-1.5 p-3 rounded-xl text-xs transition-all hover:bg-white/5" style={{ border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.6)" }}>
                    <Send size={16} className="text-indigo-400" />
                    Enviar SOL
                  </button>
                  <button onClick={() => setReceiveModal(true)} className="flex flex-col items-center gap-1.5 p-3 rounded-xl text-xs transition-all hover:bg-white/5" style={{ border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.6)" }}>
                    <Download size={16} className="text-emerald-400" />
                    Receber
                  </button>
                  <a href={`https://solscan.io/address/${wallet.publicKey}?cluster=devnet`} target="_blank" rel="noreferrer" className="flex flex-col items-center gap-1.5 p-3 rounded-xl text-xs transition-all hover:bg-white/5" style={{ border: "1px solid rgba(255,255,255,0.08)", color: "rgba(255,255,255,0.6)" }}>
                    <ExternalLink size={16} className="text-violet-400" />
                    Solscan
                  </a>
                </div>

                <button
                  onClick={requestAirdrop}
                  disabled={loading}
                  className="w-full py-2.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2"
                  style={{ background: "rgba(20,241,149,0.1)", border: "1px solid rgba(20,241,149,0.3)", color: "#14F195" }}
                >
                  {loading ? <Loader2 size={14} className="animate-spin" /> : <Star size={14} />}
                  Solicitar Airdrop (0.5 SOL devnet)
                </button>
              </div>

              {/* Right: Transaction history */}
              <div className="glass-card p-4">
                <h3 className="text-sm font-semibold mb-3" style={{ color: "rgba(255,255,255,0.7)" }}>Histórico da Carteira</h3>
                <div className="space-y-2">
                  {mockWalletTxs.map((tx) => (
                    <div key={tx.id} className="flex items-center gap-3 py-2">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center text-xs shrink-0"
                        style={{ background: `${tx.color}20`, color: tx.color }}
                      >
                        {tx.type === "received" || tx.type === "airdrop" ? <ArrowDownLeft size={14} /> : <ArrowUpRight size={14} />}
                      </div>
                      <div className="flex-1">
                        <p className="text-xs font-medium" style={{ color: "rgba(255,255,255,0.8)" }}>{tx.desc}</p>
                        <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>{tx.date}</p>
                      </div>
                      <span className="text-xs font-bold font-mono-finance" style={{ color: tx.color }}>{tx.amount}</span>
                    </div>
                  ))}
                </div>
                <button
                  onClick={disconnectWallet}
                  className="w-full mt-4 py-2 rounded-xl text-xs text-red-400 hover:bg-red-500/10 transition-all"
                  style={{ border: "1px solid rgba(239,68,68,0.2)" }}
                >
                  Desconectar carteira
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {/* ── Cartão Virtual ── */}
      {subTab === "cartao" && (
        <>
          {!card ? (
            <div className="glass-card p-8 text-center">
              {/* CSS card illustration */}
              <div
                className="w-64 h-40 rounded-2xl mx-auto mb-6 flex items-end p-4"
                style={{ background: "linear-gradient(135deg, #1a1a2e, #16213e, #0f3460)", border: "1px solid rgba(255,255,255,0.1)" }}
              >
                <div className="w-full">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-xs text-white/40">VIRTUAL</span>
                    <div className="flex gap-1">
                      <div className="w-5 h-5 rounded-full bg-red-500/80" />
                      <div className="w-5 h-5 rounded-full bg-yellow-400/80 -ml-2" />
                    </div>
                  </div>
                  <p className="font-mono-finance text-xs text-white/60">•••• •••• •••• ••••</p>
                </div>
              </div>
              <h3 className="text-xl font-bold mb-2" style={{ color: "rgba(255,255,255,0.9)" }}>Cartão Virtual Crypto</h3>
              <p className="text-sm mb-6 max-w-sm mx-auto" style={{ color: "rgba(255,255,255,0.5)" }}>
                Crie um cartão virtual alimentado por USDC. Use para compras online como qualquer cartão Mastercard.
              </p>
              <div className="flex justify-center gap-1 mb-6">
                <div className="w-8 h-8 rounded-full bg-red-500" />
                <div className="w-8 h-8 rounded-full bg-yellow-400 -ml-3" />
              </div>
              <button
                onClick={createCard}
                disabled={loading}
                className="px-6 py-3 rounded-xl text-sm font-semibold btn-primary-gradient flex items-center gap-2 mx-auto"
              >
                {loading ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
                Criar Cartão Virtual
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {/* 3D Card */}
              <div className="flex justify-center">
                <div className="card-3d-container w-80 h-48">
                  <div className={`card-3d-inner w-80 h-48 ${cardFlipped ? "flipped" : ""}`} onClick={() => setCardFlipped(!cardFlipped)}>
                    {/* Front */}
                    <div
                      className="card-3d-front rounded-2xl p-5 flex flex-col justify-between cursor-pointer relative overflow-hidden"
                      style={{
                        background: card.status === "blocked"
                          ? "linear-gradient(135deg, #1a1a2e, #2d1b1b)"
                          : "linear-gradient(135deg, #1a1a2e, #16213e, #0f3460)",
                        border: "1px solid rgba(255,255,255,0.1)",
                      }}
                    >
                      {card.status === "blocked" && (
                        <div className="absolute inset-0 rounded-2xl flex items-center justify-center" style={{ background: "rgba(239,68,68,0.2)" }}>
                          <span className="text-red-400 font-bold text-lg tracking-widest">BLOQUEADO</span>
                        </div>
                      )}
                      <div className="flex justify-between items-start">
                        <span className="text-xs font-bold text-white/40">FinOpsHub</span>
                        <span className="text-xs text-white/40 px-1.5 py-0.5 rounded" style={{ background: "rgba(255,255,255,0.1)" }}>VIRTUAL</span>
                      </div>
                      <div>
                        <p className="font-mono-finance text-white/80 text-sm tracking-widest mb-2">
                          •••• •••• •••• {card.number.slice(-4)}
                        </p>
                        <div className="flex justify-between items-end">
                          <div>
                            <p className="text-xs text-white/40">TITULAR</p>
                            <p className="text-xs text-white/70 font-medium">{card.holderName}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-xs text-white/40">VALIDADE</p>
                            <p className="text-xs text-white/70 font-mono-finance">{card.expiry}</p>
                          </div>
                          <div className="flex gap-1">
                            <div className="w-6 h-6 rounded-full bg-red-500/80" />
                            <div className="w-6 h-6 rounded-full bg-yellow-400/80 -ml-2" />
                          </div>
                        </div>
                      </div>
                    </div>
                    {/* Back */}
                    <div
                      className="card-3d-back rounded-2xl p-5 flex flex-col justify-between cursor-pointer"
                      style={{
                        background: "linear-gradient(135deg, #0f0f1a, #1a1a2e)",
                        border: "1px solid rgba(255,255,255,0.1)",
                      }}
                    >
                      <div className="h-10 w-full rounded" style={{ background: "rgba(0,0,0,0.6)", marginTop: 8 }} />
                      <div className="space-y-2">
                        <p className="text-xs text-white/40">CVV</p>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-8 rounded flex items-center px-3" style={{ background: "rgba(255,255,255,0.1)" }}>
                            <span className="font-mono-finance text-sm text-white/80">
                              {cvvVisible ? card.cvv : "•••"}
                            </span>
                          </div>
                          <button
                            onClick={(e) => { e.stopPropagation(); setCvvVisible(!cvvVisible); }}
                            className="p-1.5 rounded-lg hover:bg-white/10"
                          >
                            {cvvVisible ? <EyeOff size={14} className="text-white/50" /> : <Eye size={14} className="text-white/50" />}
                          </button>
                        </div>
                        <p className="text-xs text-center text-white/30">Clique no cartão para virar</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Card balance */}
              <div className="glass-card p-4">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>Saldo BRL</p>
                    <p className="text-xl font-bold font-mono-finance" style={{ color: "rgba(255,255,255,0.9)" }}>
                      {balVis ? fmtBRL(card.balance) : "•••"}
                    </p>
                  </div>
                  <div>
                    <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>Saldo USDC</p>
                    <p className="text-xl font-bold font-mono-finance text-emerald-400">
                      {balVis ? card.usdcBalance.toFixed(2) : "•••"}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setFundModal(true)}
                    className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
                    style={{ background: "rgba(16,185,129,0.15)", border: "1px solid rgba(16,185,129,0.3)", color: "#10b981" }}
                  >
                    Carregar Cartão
                  </button>
                  <button
                    onClick={toggleCardStatus}
                    className="flex-1 py-2.5 rounded-xl text-sm font-semibold"
                    style={{
                      background: card.status === "blocked" ? "rgba(16,185,129,0.15)" : "rgba(239,68,68,0.15)",
                      border: `1px solid ${card.status === "blocked" ? "rgba(16,185,129,0.3)" : "rgba(239,68,68,0.3)"}`,
                      color: card.status === "blocked" ? "#10b981" : "#ef4444",
                    }}
                  >
                    {card.status === "blocked"
                      ? <><Unlock size={14} className="inline mr-1" />Desbloquear</>
                      : <><Lock size={14} className="inline mr-1" />Bloquear</>}
                  </button>
                </div>
              </div>

              {/* Card transactions */}
              <div className="glass-card p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.7)" }}>Transações do Cartão</h3>
                  <button
                    onClick={() => setPurchaseModal(true)}
                    className="text-xs px-3 py-1.5 rounded-lg btn-primary-gradient"
                  >
                    Simular compra
                  </button>
                </div>
                <div className="space-y-2">
                  {cardTxs.length === 0 ? (
                    <p className="text-xs text-center py-4" style={{ color: "rgba(255,255,255,0.3)" }}>Nenhuma transação ainda.</p>
                  ) : (
                    cardTxs.map((tx) => (
                      <div key={tx.id} className="flex items-center gap-3 py-2">
                        <div className="w-8 h-8 rounded-xl flex items-center justify-center text-xs shrink-0" style={{ background: tx.type === "fund" ? "rgba(16,185,129,0.15)" : "rgba(99,102,241,0.15)" }}>
                          {tx.type === "fund" ? <Download size={14} className="text-emerald-400" /> : <CreditCard size={14} className="text-indigo-400" />}
                        </div>
                        <div className="flex-1">
                          <p className="text-xs font-medium" style={{ color: "rgba(255,255,255,0.8)" }}>{tx.merchant}</p>
                          <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>{tx.date} • {Math.abs(tx.usdcDeducted).toFixed(2)} USDC</p>
                        </div>
                        <span className="text-xs font-bold font-mono-finance" style={{ color: tx.type === "fund" ? "#10b981" : "#ef4444" }}>
                          {tx.type === "fund" ? "+" : "-"}{fmtBRL(tx.amountBRL)}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* ── Phantom Modal ── */}
      <Modal open={phantomModal} onClose={() => setPhantomModal(false)}>
        <div className="p-6 text-center">
          <div className="w-16 h-16 rounded-2xl mx-auto mb-4 flex items-center justify-center" style={{ background: "rgba(153,69,255,0.2)" }}>
            <span className="text-3xl">👻</span>
          </div>
          <h3 className="text-lg font-bold mb-1" style={{ color: "rgba(255,255,255,0.9)" }}>Phantom</h3>
          <p className="text-sm mb-1" style={{ color: "rgba(255,255,255,0.5)" }}>FinOpsHub quer se conectar à sua carteira</p>
          <p className="text-xs mb-6 font-mono-finance" style={{ color: "rgba(255,255,255,0.3)" }}>finopshub.manus.space</p>
          <div className="flex gap-3">
            <button onClick={() => setPhantomModal(false)} className="flex-1 py-2.5 rounded-xl text-sm" style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.5)" }}>
              Cancelar
            </button>
            <button onClick={connectPhantom} disabled={loading} className="flex-1 py-2.5 rounded-xl text-sm font-semibold" style={{ background: "rgba(153,69,255,0.3)", border: "1px solid rgba(153,69,255,0.5)", color: "#9945FF" }}>
              {loading ? <Loader2 size={14} className="animate-spin inline" /> : "Conectar"}
            </button>
          </div>
        </div>
      </Modal>

      {/* ── Create Wallet Modal ── */}
      <Modal open={createModal} onClose={() => setCreateModal(false)}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Criar Nova Carteira</h3>
            <button onClick={() => setCreateModal(false)}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
          </div>
          <div className="p-3 rounded-xl mb-4 flex gap-2" style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.2)" }}>
            <AlertCircle size={16} className="text-amber-400 shrink-0 mt-0.5" />
            <p className="text-xs text-amber-400">Uma nova carteira será criada na Solana devnet para fins de demonstração.</p>
          </div>
          <button onClick={createWallet} disabled={loading} className="w-full py-3 rounded-xl text-sm font-semibold btn-primary-gradient flex items-center justify-center gap-2">
            {loading ? <Loader2 size={14} className="animate-spin" /> : <Plus size={14} />}
            Criar Carteira
          </button>
        </div>
      </Modal>

      {/* ── Send SOL Modal ── */}
      <Modal open={sendModal} onClose={() => setSendModal(false)}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Enviar SOL</h3>
            <button onClick={() => setSendModal(false)}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
          </div>
          <div className="space-y-3">
            <div>
              <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Endereço destino</label>
              <input value={sendDest} onChange={(e) => setSendDest(e.target.value)} placeholder="Endereço Solana" className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }} />
            </div>
            <div>
              <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Quantidade (SOL)</label>
              <input type="number" value={sendAmount} onChange={(e) => setSendAmount(e.target.value)} placeholder="0.0" className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }} />
            </div>
            <p className="text-xs" style={{ color: "rgba(255,255,255,0.3)" }}>Taxa estimada: ~0.000005 SOL</p>
            <button onClick={sendSOL} disabled={loading} className="w-full py-3 rounded-xl text-sm font-semibold btn-primary-gradient flex items-center justify-center gap-2">
              {loading ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}
              Enviar
            </button>
          </div>
        </div>
      </Modal>

      {/* ── Receive Modal ── */}
      <Modal open={receiveModal} onClose={() => setReceiveModal(false)}>
        <div className="p-6 text-center">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Receber SOL</h3>
            <button onClick={() => setReceiveModal(false)}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
          </div>
          {wallet && (
            <>
              <div className="flex justify-center mb-4">
                <QRCodeSVG seed={wallet.publicKey} size={160} />
              </div>
              <p className="font-mono-finance text-xs mb-3" style={{ color: "rgba(255,255,255,0.5)" }}>{truncateKey(wallet.publicKey)}</p>
              <button onClick={() => { navigator.clipboard.writeText(wallet.publicKey); toast.success("Endereço copiado!"); }} className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm mx-auto" style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}>
                <Copy size={14} /> Copiar endereço
              </button>
            </>
          )}
        </div>
      </Modal>

      {/* ── Fund Card Modal ── */}
      <Modal open={fundModal} onClose={() => setFundModal(false)}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Carregar Cartão</h3>
            <button onClick={() => setFundModal(false)}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
          </div>
          {!wallet ? (
            <div className="p-3 rounded-xl text-sm text-amber-400" style={{ background: "rgba(245,158,11,0.1)", border: "1px solid rgba(245,158,11,0.2)" }}>
              Conecte sua carteira Solana para carregar o cartão
            </div>
          ) : (
            <div className="space-y-3">
              <div className="p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.03)" }}>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>USDC disponível na carteira</p>
                <p className="text-xl font-bold font-mono-finance text-emerald-400">{wallet.usdcBalance.toFixed(2)} USDC</p>
              </div>
              <div>
                <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Quantidade USDC</label>
                <input type="number" value={fundAmount} onChange={(e) => setFundAmount(e.target.value)} placeholder="0.00" className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }} />
                {fundAmount && <p className="text-xs mt-1 text-indigo-400">≈ {fmtBRL(parseFloat(fundAmount || "0") * 5)}</p>}
              </div>
              <button onClick={fundCard} disabled={loading} className="w-full py-3 rounded-xl text-sm font-semibold" style={{ background: "rgba(16,185,129,0.2)", border: "1px solid rgba(16,185,129,0.3)", color: "#10b981" }}>
                {loading ? <Loader2 size={14} className="animate-spin inline mr-2" /> : null}
                Carregar
              </button>
            </div>
          )}
        </div>
      </Modal>

      {/* ── Purchase Modal ── */}
      <Modal open={purchaseModal} onClose={() => setPurchaseModal(false)}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Simular Compra</h3>
            <button onClick={() => setPurchaseModal(false)}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
          </div>
          <div className="space-y-3">
            <div>
              <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Estabelecimento</label>
              <input value={purchaseMerchant} onChange={(e) => setPurchaseMerchant(e.target.value)} placeholder="Ex: Amazon, Netflix..." className="w-full px-3 py-2.5 rounded-xl text-sm" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }} />
            </div>
            <div>
              <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Valor (BRL)</label>
              <input type="number" value={purchaseAmount} onChange={(e) => setPurchaseAmount(e.target.value)} placeholder="0,00" className="w-full px-3 py-2.5 rounded-xl text-sm font-mono-finance" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }} />
              {purchaseAmount && <p className="text-xs mt-1 text-indigo-400">≈ {(parseFloat(purchaseAmount || "0") / 5).toFixed(2)} USDC</p>}
            </div>
            <button onClick={simulatePurchase} disabled={loading} className="w-full py-3 rounded-xl text-sm font-semibold btn-primary-gradient">
              {loading ? <Loader2 size={14} className="animate-spin inline mr-2" /> : null}
              Confirmar Compra
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

// ─── Antecipar View ───────────────────────────────────────────────────────────
function AnteciparView({ authToken }: { authToken: string }) {
  const [nfes, setNfes] = useState<NFe[]>([]);
  const [operacoes, setOperacoes] = useState<Operacao[]>([]);
  const [health, setHealth] = useState<{ status: string } | null>(null);
  const [loading, setLoading] = useState(false);
  const [simModal, setSimModal] = useState(false);
  const [selectedNfe, setSelectedNfe] = useState<NFe | null>(null);
  const [quote, setQuote] = useState<DeFiQuote | null>(null);
  const [simLoading, setSimLoading] = useState(false);
  const [execLoading, setExecLoading] = useState(false);

  // tRPC queries and mutations
  const healthQuery = trpc.defi.health.useQuery();
  const nfesQuery = trpc.defi.nfes.useQuery();
  const operacoesQuery = trpc.defi.operacoes.useQuery();
  const simularMut = trpc.defi.simular.useMutation();
  const executarMut = trpc.defi.executar.useMutation();
  const utils = trpc.useUtils();

  useEffect(() => {
    if (healthQuery.data) setHealth(healthQuery.data);
  }, [healthQuery.data]);

  useEffect(() => {
    if (nfesQuery.data?.nfes) setNfes(nfesQuery.data.nfes as NFe[]);
  }, [nfesQuery.data]);

  useEffect(() => {
    if (operacoesQuery.data) setOperacoes(operacoesQuery.data as Operacao[]);
  }, [operacoesQuery.data]);

  const loadData = useCallback(async () => {
    await utils.defi.health.invalidate();
    await utils.defi.nfes.invalidate();
    await utils.defi.operacoes.invalidate();
  }, [utils]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleSimular = async (nfe: NFe) => {
    setSelectedNfe(nfe);
    setSimLoading(true);
    try {
      const data = await simularMut.mutateAsync({ nfeId: nfe.id });
      setQuote(data.quote as DeFiQuote);
      setSimModal(true);
    } catch (e: any) { toast.error(e.message || "Erro na simulação"); }
    setSimLoading(false);
  };

  const handleExecutar = async () => {
    if (!selectedNfe) return;
    setExecLoading(true);
    try {
      const data = await executarMut.mutateAsync({ nfeId: selectedNfe.id });
      setSimModal(false);
      await loadData();
      toast.success(`NF-e antecipada! TX: ${data.operacao.txHash.slice(0, 16)}...`);
    } catch (e: any) { toast.error(e.message); }
    setExecLoading(false);
  };

    const pendentes = nfes.filter((n) => n.status === "pendente");
  const totalElegivel = pendentes.reduce((s, n) => s + n.valor, 0);
  const totalAntecipado = operacoes.reduce((s, o) => s + o.liquidoBRL, 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Antecipar Recebíveis</h2>
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>DeFi via Kamino Finance • Solana devnet</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs" style={{
            background: health?.status === "online" ? "rgba(16,185,129,0.1)" : "rgba(239,68,68,0.1)",
            border: `1px solid ${health?.status === "online" ? "rgba(16,185,129,0.3)" : "rgba(239,68,68,0.3)"}`,
            color: health?.status === "online" ? "#10b981" : "#ef4444"
          }}>
            <span className="w-1.5 h-1.5 rounded-full" style={{ background: "currentColor", display: "inline-block" }} />
            {health?.status === "online" ? "Online" : "Offline"}
          </div>
          <button onClick={loadData} className="p-2 rounded-xl hover:bg-white/5" style={{ border: "1px solid rgba(255,255,255,0.08)" }}>
            <RefreshCw size={14} style={{ color: "rgba(255,255,255,0.5)" }} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "NF-es Pendentes", value: pendentes.length.toString(), color: "#6366f1", icon: <FileText size={16} /> },
          { label: "Volume Elegível", value: fmtBRL(totalElegivel), color: "#f59e0b", icon: <DollarSign size={16} /> },
          { label: "Já Antecipado", value: fmtBRL(totalAntecipado), color: "#10b981", icon: <CheckCircle size={16} /> },
          { label: "Operações", value: operacoes.length.toString(), color: "#9945FF", icon: <Activity size={16} /> },
        ].map((kpi) => (
          <div key={kpi.label} className="glass-card p-4">
            <div className="flex items-center justify-between mb-2">
              <span style={{ color: kpi.color }}>{kpi.icon}</span>
            </div>
            <p className="text-xl font-bold font-mono-finance" style={{ color: "rgba(255,255,255,0.9)" }}>{kpi.value}</p>
            <p className="text-xs mt-0.5" style={{ color: "rgba(255,255,255,0.4)" }}>{kpi.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7 glass-card p-4">
          <h3 className="text-sm font-semibold mb-3" style={{ color: "rgba(255,255,255,0.7)" }}>Notas Fiscais Eletrônicas</h3>
          {loading ? (
            <div className="space-y-2">
              {[1, 2, 3].map((i) => <div key={i} className="h-16 rounded-xl shimmer" />)}
            </div>
          ) : (
            <div className="space-y-2">
              {nfes.map((nfe) => (
                <div key={nfe.id} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)" }}>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-medium" style={{ color: "rgba(255,255,255,0.85)" }}>{nfe.numero}</p>
                      <StatusBadge status={nfe.status} />
                    </div>
                    <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>{nfe.cliente} • Vence em {nfe.diasVencimento}d</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold font-mono-finance" style={{ color: "rgba(255,255,255,0.9)" }}>{fmtBRL(nfe.valor)}</p>
                    {nfe.status === "pendente" && (
                      <button
                        onClick={() => handleSimular(nfe)}
                        disabled={simLoading}
                        className="text-xs px-3 py-1 rounded-lg mt-1 btn-primary-gradient"
                      >
                        {simLoading ? "..." : "Simular"}
                      </button>
                    )}
                    {nfe.status === "antecipada" && nfe.txHash && (
                      <a href={`https://solscan.io/tx/${nfe.txHash}?cluster=devnet`} target="_blank" rel="noreferrer" className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 mt-1">
                        <ExternalLink size={10} /> Solscan
                      </a>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-5 space-y-4">
          <div className="rounded-xl p-4" style={{ background: "linear-gradient(135deg, rgba(153,69,255,0.15) 0%, rgba(20,241,149,0.08) 100%)", border: "1px solid rgba(153,69,255,0.3)" }}>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-lg">◎</span>
              <span className="text-sm font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Kamino Finance</span>
              <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "rgba(20,241,149,0.15)", color: "#14F195" }}>devnet</span>
            </div>
            <p className="text-xs mb-3" style={{ color: "rgba(255,255,255,0.5)" }}>Protocolo DeFi de antecipação de recebíveis. LTV 70%, taxa 1.2%/mês.</p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.05)" }}>
                <p style={{ color: "rgba(255,255,255,0.4)" }}>LTV</p>
                <p className="font-bold text-indigo-400">70%</p>
              </div>
              <div className="p-2 rounded-lg" style={{ background: "rgba(255,255,255,0.05)" }}>
                <p style={{ color: "rgba(255,255,255,0.4)" }}>Taxa/mês</p>
                <p className="font-bold text-indigo-400">1.2%</p>
              </div>
            </div>
          </div>

          <div className="glass-card p-4">
            <h3 className="text-sm font-semibold mb-3" style={{ color: "rgba(255,255,255,0.7)" }}>Histórico de Operações</h3>
            {operacoes.length === 0 ? (
              <p className="text-xs text-center py-4" style={{ color: "rgba(255,255,255,0.3)" }}>Nenhuma operação ainda.</p>
            ) : (
              <div className="space-y-2">
                {operacoes.map((op) => (
                  <div key={op.id} className="p-2 rounded-xl" style={{ background: "rgba(255,255,255,0.02)" }}>
                    <div className="flex justify-between mb-0.5">
                      <span className="text-xs font-medium" style={{ color: "rgba(255,255,255,0.8)" }}>{op.nfeNumero}</span>
                      <span className="text-xs font-bold text-emerald-400 font-mono-finance">{fmtBRL(op.liquidoBRL)}</span>
                    </div>
                    <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>{op.cliente}</p>
                    <a href={`https://solscan.io/tx/${op.txHash}?cluster=devnet`} target="_blank" rel="noreferrer" className="text-xs text-indigo-400 flex items-center gap-1 mt-1">
                      <ExternalLink size={10} /> {op.txHash.slice(0, 16)}...
                    </a>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <Modal open={simModal} onClose={() => setSimModal(false)} maxWidth="max-w-xl">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Simulação DeFi</h3>
            <button onClick={() => setSimModal(false)}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
          </div>
          {selectedNfe && quote && (
            <>
              <div className="flex items-center justify-between mb-4 p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.03)" }}>
                <div className="text-center">
                  <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>NF-e</p>
                  <p className="text-sm font-bold font-mono-finance" style={{ color: "rgba(255,255,255,0.9)" }}>{fmtBRL(quote.valorOriginalBRL)}</p>
                </div>
                <ArrowRightLeft size={16} style={{ color: "rgba(255,255,255,0.3)" }} />
                <div className="text-center">
                  <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>USDC</p>
                  <p className="text-sm font-bold font-mono-finance text-indigo-400">{quote.valorUSDC}</p>
                </div>
                <ArrowRightLeft size={16} style={{ color: "rgba(255,255,255,0.3)" }} />
                <div className="text-center">
                  <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>Líquido</p>
                  <p className="text-sm font-bold font-mono-finance text-emerald-400">{fmtBRL(quote.liquidoBRL)}</p>
                </div>
              </div>
              <div className="space-y-2 mb-4">
                {[
                  ["Valor original", fmtBRL(quote.valorOriginalBRL), "rgba(255,255,255,0.7)"],
                  ["Valor em USDC", `${quote.valorUSDC} USDC`, "#818cf8"],
                  ["LTV (70%)", `${(quote.ltvRatio * 100).toFixed(0)}%`, "rgba(255,255,255,0.6)"],
                  ["Taxa total", `${quote.custoPercent.toFixed(2)}%`, "#f59e0b"],
                  ["Custo total", fmtBRL(quote.custoTotalBRL), "#ef4444"],
                  ["Líquido USDC", `${quote.liquidoUSDC} USDC`, "#10b981"],
                  ["Líquido BRL", fmtBRL(quote.liquidoBRL), "#10b981"],
                  ["Economia vs. factoring", fmtBRL(quote.economiaVsFactoring), "#14F195"],
                ].map(([label, value, color]) => (
                  <div key={label} className="flex justify-between text-xs py-1.5 border-b" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
                    <span style={{ color: "rgba(255,255,255,0.5)" }}>{label}</span>
                    <span className="font-mono-finance font-semibold" style={{ color }}>{value}</span>
                  </div>
                ))}
              </div>
              <p className="text-xs mb-4" style={{ color: "rgba(255,255,255,0.3)" }}>Protocolo: {quote.protocolo}</p>
              <button onClick={handleExecutar} disabled={execLoading} className="w-full py-3 rounded-xl text-sm font-semibold btn-primary-gradient flex items-center justify-center gap-2">
                {execLoading ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle size={14} />}
                Confirmar Antecipação
              </button>
            </>
          )}
        </div>
      </Modal>
    </div>
  );
}

// ─── Payroll Dashboard ────────────────────────────────────────────────────────
function PayrollDashboard({
  employees, batches, accounts, balVis, setBatches, setAccounts, setTransactions,
}: {
  employees: Employee[];
  batches: PayrollBatch[];
  accounts: Account[];
  balVis: boolean;
  setBatches: React.Dispatch<React.SetStateAction<PayrollBatch[]>>;
  setAccounts: React.Dispatch<React.SetStateAction<Account[]>>;
  setTransactions: React.Dispatch<React.SetStateAction<Transaction[]>>;
}) {
  const [payModal, setPayModal] = useState(false);
  const [selectedBatch, setSelectedBatch] = useState<PayrollBatch | null>(null);

  const totalGross = employees.reduce((s, e) => s + e.salary, 0);
  const totalCalcs = employees.map(calcEmployee);
  const totalINSS = totalCalcs.reduce((s, c) => s + c.inss, 0);
  const totalIRRF = totalCalcs.reduce((s, c) => s + c.irrf, 0);
  const totalNet = totalCalcs.reduce((s, c) => s + c.net, 0);

  const trendData = [
    { month: "Fev", gross: 67200, net: 47100 },
    { month: "Mar", gross: 68500, net: 47900 },
    { month: "Abr", gross: totalGross, net: totalNet },
  ];

  const deptData = useMemo(() => {
    const map: Record<string, number> = {};
    employees.forEach((e) => { map[e.dept] = (map[e.dept] || 0) + e.salary; });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [employees]);

  const DEPT_COLORS = ["#6366f1", "#10b981", "#f59e0b", "#9945FF", "#ef4444", "#14F195"];

  const handlePayBatch = (batch: PayrollBatch) => {
    setSelectedBatch(batch);
    setPayModal(true);
  };

  const confirmPayBatch = () => {
    if (!selectedBatch) return;
    setBatches((prev) => prev.map((b) => b.id === selectedBatch.id ? { ...b, status: "paid" as const, paidAt: new Date() } : b));
    setAccounts((prev) => prev.map((a) => a.id === "1" ? { ...a, balance: a.balance - selectedBatch.totalNet } : a));
    setTransactions((prev) => [{
      id: `t-folha-${Date.now()}`,
      date: new Date(),
      desc: `Pagamento Folha — ${fmtMonth(selectedBatch.month)}`,
      amount: selectedBatch.totalNet,
      cat: "Folha",
      bankId: "1",
      type: "expense" as const,
    }, ...prev]);
    setPayModal(false);
    toast.success(`Folha ${fmtMonth(selectedBatch.month)} paga com sucesso!`);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total Folha", value: fmtBRL(totalGross), color: "#6366f1", spark: [65000, 67000, 68500, totalGross] },
          { label: "Impostos", value: fmtBRL(totalINSS + totalIRRF), color: "#ef4444", spark: [18000, 19500, 20600, totalINSS + totalIRRF] },
          { label: "Líquido", value: fmtBRL(totalNet), color: "#10b981", spark: [44000, 46000, 47900, totalNet] },
          { label: "Colaboradores", value: employees.length.toString(), color: "#9945FF", spark: [6, 7, 8, employees.length] },
        ].map((kpi) => (
          <div key={kpi.label} className="glass-card p-4">
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>{kpi.label}</p>
              <MiniSparkline data={kpi.spark} color={kpi.color} />
            </div>
            <p className="text-xl font-bold font-mono-finance" style={{ color: kpi.color }}>
              {balVis ? kpi.value : "•••"}
            </p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass-card p-4">
          <h3 className="text-sm font-semibold mb-3" style={{ color: "rgba(255,255,255,0.7)" }}>Tendência da Folha</h3>
          <ResponsiveContainer width="100%" height={160}>
            <AreaChart data={trendData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="grossGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="netGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="month" tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "rgba(255,255,255,0.4)", fontSize: 11 }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "rgba(13,11,29,0.95)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, fontSize: 12 }} formatter={(v: number) => fmtBRL(v)} />
              <Area type="monotone" dataKey="gross" stroke="#6366f1" strokeWidth={2} fill="url(#grossGrad)" name="Bruto" />
              <Area type="monotone" dataKey="net" stroke="#10b981" strokeWidth={2} fill="url(#netGrad)" name="Líquido" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="glass-card p-4">
          <h3 className="text-sm font-semibold mb-3" style={{ color: "rgba(255,255,255,0.7)" }}>Custo por Departamento</h3>
          <div className="flex items-center gap-4">
            <ResponsiveContainer width={140} height={140}>
              <PieChart>
                <Pie data={deptData} cx="50%" cy="50%" innerRadius={40} outerRadius={65} dataKey="value" paddingAngle={2}>
                  {deptData.map((_, i) => <Cell key={i} fill={DEPT_COLORS[i % DEPT_COLORS.length]} />)}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="space-y-1.5 flex-1">
              {deptData.map((d, i) => (
                <div key={d.name} className="flex items-center gap-2 text-xs">
                  <div className="w-2 h-2 rounded-full shrink-0" style={{ background: DEPT_COLORS[i % DEPT_COLORS.length] }} />
                  <span style={{ color: "rgba(255,255,255,0.6)" }}>{d.name}</span>
                  <span className="ml-auto font-mono-finance" style={{ color: "rgba(255,255,255,0.8)" }}>{fmtBRL(d.value)}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="glass-card p-4">
        <h3 className="text-sm font-semibold mb-3" style={{ color: "rgba(255,255,255,0.7)" }}>Lotes de Folha</h3>
        <div className="space-y-2">
          {batches.map((batch) => (
            <div key={batch.id} className="flex items-center gap-3 p-3 rounded-xl" style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.05)" }}>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="text-sm font-semibold" style={{ color: "rgba(255,255,255,0.85)" }}>{fmtMonth(batch.month)}</p>
                  <StatusBadge status={batch.status} />
                </div>
                <p className="text-xs" style={{ color: "rgba(255,255,255,0.4)" }}>
                  Bruto: {balVis ? fmtBRL(batch.totalGross) : "•••"} • Impostos: {balVis ? fmtBRL(batch.totalTaxes) : "•••"}
                </p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold font-mono-finance text-emerald-400">{balVis ? fmtBRL(batch.totalNet) : "•••"}</p>
                {batch.status === "calculated" && (
                  <button onClick={() => handlePayBatch(batch)} className="text-xs px-3 py-1 rounded-lg mt-1 btn-primary-gradient">Pagar</button>
                )}
                {batch.status === "paid" && batch.paidAt && (
                  <p className="text-xs mt-1" style={{ color: "rgba(255,255,255,0.3)" }}>Pago em {fmtDate(batch.paidAt)}</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <Modal open={payModal} onClose={() => setPayModal(false)}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Pagar Folha</h3>
            <button onClick={() => setPayModal(false)}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
          </div>
          {selectedBatch && (
            <>
              <div className="text-center mb-4">
                <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>Total Líquido</p>
                <p className="text-3xl font-bold font-mono-finance text-emerald-400">{fmtBRL(selectedBatch.totalNet)}</p>
                <p className="text-sm mt-1" style={{ color: "rgba(255,255,255,0.5)" }}>Competência: {fmtMonth(selectedBatch.month)}</p>
              </div>
              <div className="p-3 rounded-xl mb-4 flex items-center gap-2" style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)" }}>
                <Shield size={14} className="text-indigo-400" />
                <span className="text-xs text-indigo-400">PIX Batch seguro • {employees.length} colaboradores</span>
              </div>
              <button onClick={confirmPayBatch} className="w-full py-3 rounded-xl text-sm font-semibold btn-primary-gradient">
                Confirmar Pagamento
              </button>
            </>
          )}
        </div>
      </Modal>
    </div>
  );
}

// ─── Equipe View ──────────────────────────────────────────────────────────────
function EquipeView({ employees, balVis }: { employees: Employee[]; balVis: boolean }) {
  const [selected, setSelected] = useState<Employee | null>(null);
  const calc = selected ? calcEmployee(selected) : null;

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Equipe</h2>
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                {["Colaborador", "CPF", "Cargo", "Dept.", "Bruto", "Líquido"].map((h) => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "rgba(255,255,255,0.4)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {employees.map((emp) => {
                const c = calcEmployee(emp);
                return (
                  <tr key={emp.id} onClick={() => setSelected(emp)} className="cursor-pointer transition-all hover:bg-white/3" style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white shrink-0" style={{ background: "linear-gradient(135deg, #6366f1, #9945FF)" }}>
                          {emp.name.split(" ").slice(0, 2).map((w) => w[0]).join("")}
                        </div>
                        <span className="text-sm" style={{ color: "rgba(255,255,255,0.85)" }}>{emp.name}</span>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs font-mono-finance" style={{ color: "rgba(255,255,255,0.5)" }}>{fmtCPF(emp.cpf)}</td>
                    <td className="px-4 py-3 text-xs" style={{ color: "rgba(255,255,255,0.6)" }}>{emp.role}</td>
                    <td className="px-4 py-3"><DeptBadge dept={emp.dept} /></td>
                    <td className="px-4 py-3 text-sm font-mono-finance" style={{ color: "rgba(255,255,255,0.7)" }}>{balVis ? fmtBRL(emp.salary) : "•••"}</td>
                    <td className="px-4 py-3 text-sm font-bold font-mono-finance text-emerald-400">{balVis ? fmtBRL(c.net) : "•••"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      <Modal open={!!selected} onClose={() => setSelected(null)}>
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Detalhes do Colaborador</h3>
            <button onClick={() => setSelected(null)}><X size={18} style={{ color: "rgba(255,255,255,0.4)" }} /></button>
          </div>
          {selected && calc && (
            <>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-sm font-bold text-white" style={{ background: "linear-gradient(135deg, #6366f1, #9945FF)" }}>
                  {selected.name.split(" ").slice(0, 2).map((w) => w[0]).join("")}
                </div>
                <div>
                  <p className="font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>{selected.name}</p>
                  <p className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>{selected.role}</p>
                  <DeptBadge dept={selected.dept} />
                </div>
              </div>
              <div className="space-y-2">
                {[
                  ["Salário Bruto", fmtBRL(calc.gross), "rgba(255,255,255,0.8)"],
                  ["INSS", `- ${fmtBRL(calc.inss)}`, "#ef4444"],
                  ["IRRF", `- ${fmtBRL(calc.irrf)}`, "#ef4444"],
                  ["FGTS (custo emp.)", fmtBRL(calc.fgts), "#f59e0b"],
                  ["Dependentes", selected.dep.toString(), "rgba(255,255,255,0.6)"],
                  ["Salário Líquido", fmtBRL(calc.net), "#10b981"],
                ].map(([label, value, color]) => (
                  <div key={label} className="flex justify-between py-2 border-b" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
                    <span className="text-sm" style={{ color: "rgba(255,255,255,0.5)" }}>{label}</span>
                    <span className="text-sm font-bold font-mono-finance" style={{ color }}>{value}</span>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 rounded-xl text-xs space-y-1" style={{ background: "rgba(255,255,255,0.03)" }}>
                <p style={{ color: "rgba(255,255,255,0.4)" }}>Dados bancários</p>
                <p style={{ color: "rgba(255,255,255,0.7)" }}>Banco {selected.bankCode} • Ag. {selected.bankAgency} • Conta {selected.bankAccount}</p>
              </div>
            </>
          )}
        </div>
      </Modal>
    </div>
  );
}

// ─── Importar CSV View ────────────────────────────────────────────────────────
function ImportarCSVView({ onImport }: { onImport: (emps: Employee[], batch: PayrollBatch) => void }) {
  const [dragging, setDragging] = useState(false);
  const [parsed, setParsed] = useState<Employee[]>([]);
  const [step, setStep] = useState<"upload" | "preview" | "done">("upload");
  const fileRef = useRef<HTMLInputElement>(null);

  const csvTemplate = "nome,cpf,salario,dependentes,cargo,departamento,banco,agencia,conta\nJoão Silva,12345678901,5000,1,Analista,TI,260,0001,12345-6";

  const downloadTemplate = () => {
    const blob = new Blob([csvTemplate], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = "template_folha.csv"; a.click();
    URL.revokeObjectURL(url);
  };

  const processFile = (file: File) => {
    Papa.parse(file, {
      header: true,
      complete: (results) => {
        const emps: Employee[] = (results.data as any[])
          .filter((r) => r.nome && r.cpf && r.salario)
          .map((r, i) => ({
            id: `csv-${i}-${Date.now()}`,
            name: r.nome,
            cpf: r.cpf?.replace(/\D/g, ""),
            salary: parseFloat(r.salario) || 0,
            dep: parseInt(r.dependentes) || 0,
            role: r.cargo || "Colaborador",
            dept: r.departamento || "Geral",
            bankCode: r.banco || "260",
            bankAgency: r.agencia || "0001",
            bankAccount: r.conta || "00000-0",
          }));
        if (emps.length === 0) { toast.error("Nenhum funcionário válido encontrado"); return; }
        setParsed(emps);
        setStep("preview");
      },
      error: () => toast.error("Erro ao processar CSV"),
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) processFile(file);
  };

  const handleSave = () => {
    const totalGross = parsed.reduce((s, e) => s + e.salary, 0);
    const calcs = parsed.map(calcEmployee);
    const totalNet = calcs.reduce((s, c) => s + c.net, 0);
    const totalTaxes = calcs.reduce((s, c) => s + c.inss + c.irrf, 0);
    const batch: PayrollBatch = {
      id: `b-csv-${Date.now()}`,
      month: new Date().toISOString().slice(0, 7),
      status: "calculated",
      totalGross,
      totalNet,
      totalTaxes,
      createdAt: new Date(),
    };
    onImport(parsed, batch);
    setStep("done");
    toast.success(`${parsed.length} funcionários importados!`);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Importar CSV</h2>
        <button onClick={downloadTemplate} className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs" style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}>
          <Download size={12} /> Template CSV
        </button>
      </div>

      {step === "upload" && (
        <div
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          onClick={() => fileRef.current?.click()}
          className="border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all"
          style={{ borderColor: dragging ? "#6366f1" : "rgba(255,255,255,0.1)", background: dragging ? "rgba(99,102,241,0.05)" : "transparent" }}
        >
          <Upload size={32} className="mx-auto mb-3" style={{ color: "rgba(255,255,255,0.3)" }} />
          <p className="text-sm font-medium mb-1" style={{ color: "rgba(255,255,255,0.7)" }}>Arraste e solte o arquivo CSV</p>
          <p className="text-xs" style={{ color: "rgba(255,255,255,0.35)" }}>ou clique para selecionar</p>
          <input ref={fileRef} type="file" accept=".csv" className="hidden" onChange={(e) => { if (e.target.files?.[0]) processFile(e.target.files[0]); }} />
        </div>
      )}

      {step === "preview" && (
        <div className="space-y-4">
          <div className="glass-card overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                    {["Nome", "Cargo", "Bruto", "INSS", "IRRF", "FGTS", "Líquido"].map((h) => (
                      <th key={h} className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "rgba(255,255,255,0.4)" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {parsed.map((emp) => {
                    const c = calcEmployee(emp);
                    return (
                      <tr key={emp.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                        <td className="px-4 py-2 text-sm" style={{ color: "rgba(255,255,255,0.8)" }}>{emp.name}</td>
                        <td className="px-4 py-2 text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>{emp.role}</td>
                        <td className="px-4 py-2 text-xs font-mono-finance" style={{ color: "rgba(255,255,255,0.7)" }}>{fmtBRL(c.gross)}</td>
                        <td className="px-4 py-2 text-xs font-mono-finance text-red-400">-{fmtBRL(c.inss)}</td>
                        <td className="px-4 py-2 text-xs font-mono-finance text-red-400">-{fmtBRL(c.irrf)}</td>
                        <td className="px-4 py-2 text-xs font-mono-finance text-amber-400">{fmtBRL(c.fgts)}</td>
                        <td className="px-4 py-2 text-sm font-bold font-mono-finance text-emerald-400">{fmtBRL(c.net)}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep("upload")} className="px-4 py-2.5 rounded-xl text-sm" style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}>Cancelar</button>
            <button onClick={handleSave} className="flex-1 py-2.5 rounded-xl text-sm font-semibold btn-primary-gradient">
              Salvar e Finalizar ({parsed.length} funcionários)
            </button>
          </div>
        </div>
      )}

      {step === "done" && (
        <div className="glass-card p-8 text-center">
          <CheckCircle size={48} className="text-emerald-400 mx-auto mb-4" />
          <h3 className="text-lg font-bold mb-2" style={{ color: "rgba(255,255,255,0.9)" }}>Importação concluída!</h3>
          <p className="text-sm mb-4" style={{ color: "rgba(255,255,255,0.5)" }}>{parsed.length} funcionários importados e folha calculada.</p>
          <button onClick={() => setStep("upload")} className="px-6 py-2.5 rounded-xl text-sm btn-primary-gradient">Nova importação</button>
        </div>
      )}
    </div>
  );
}

// ─── Simulação View ───────────────────────────────────────────────────────────
function SimulacaoView({ employees, balVis }: { employees: Employee[]; balVis: boolean }) {
  const calcs = employees.map((e) => ({ ...e, ...calcEmployee(e) }));
  const totals = calcs.reduce(
    (acc, c) => ({ gross: acc.gross + c.gross, inss: acc.inss + c.inss, irrf: acc.irrf + c.irrf, fgts: acc.fgts + c.fgts, net: acc.net + c.net }),
    { gross: 0, inss: 0, irrf: 0, fgts: 0, net: 0 }
  );

  return (
    <div className="space-y-4">
      <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Simulação da Folha</h2>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { label: "Bruto Total", value: totals.gross, color: "#6366f1" },
          { label: "INSS Total", value: totals.inss, color: "#ef4444" },
          { label: "IRRF Total", value: totals.irrf, color: "#f59e0b" },
          { label: "FGTS Total", value: totals.fgts, color: "#9945FF" },
          { label: "Líquido Total", value: totals.net, color: "#10b981" },
        ].map((s) => (
          <div key={s.label} className="glass-card p-3">
            <p className="text-xs mb-1" style={{ color: "rgba(255,255,255,0.4)" }}>{s.label}</p>
            <p className="text-base font-bold font-mono-finance" style={{ color: s.color }}>{balVis ? fmtBRL(s.value) : "•••"}</p>
          </div>
        ))}
      </div>
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
                {["Colaborador", "Dept.", "Bruto", "INSS", "IRRF", "FGTS", "Dep.", "Líquido"].map((h) => (
                  <th key={h} className="text-left px-4 py-3 text-xs font-semibold" style={{ color: "rgba(255,255,255,0.4)" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {calcs.map((c) => (
                <tr key={c.id} style={{ borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                  <td className="px-4 py-3 text-sm" style={{ color: "rgba(255,255,255,0.8)" }}>{c.name}</td>
                  <td className="px-4 py-3"><DeptBadge dept={c.dept} /></td>
                  <td className="px-4 py-3 text-xs font-mono-finance" style={{ color: "rgba(255,255,255,0.7)" }}>{balVis ? fmtBRL(c.gross) : "•••"}</td>
                  <td className="px-4 py-3 text-xs font-mono-finance text-red-400">{balVis ? fmtBRL(c.inss) : "•••"}</td>
                  <td className="px-4 py-3 text-xs font-mono-finance text-amber-400">{balVis ? fmtBRL(c.irrf) : "•••"}</td>
                  <td className="px-4 py-3 text-xs font-mono-finance text-violet-400">{balVis ? fmtBRL(c.fgts) : "•••"}</td>
                  <td className="px-4 py-3 text-xs text-center" style={{ color: "rgba(255,255,255,0.5)" }}>{c.dep}</td>
                  <td className="px-4 py-3 text-sm font-bold font-mono-finance text-emerald-400">{balVis ? fmtBRL(c.net) : "•••"}</td>
                </tr>
              ))}
              <tr style={{ borderTop: "2px solid rgba(99,102,241,0.3)", background: "rgba(99,102,241,0.05)" }}>
                <td className="px-4 py-3 text-sm font-bold" style={{ color: "rgba(255,255,255,0.9)" }} colSpan={2}>TOTAL</td>
                <td className="px-4 py-3 text-sm font-bold font-mono-finance" style={{ color: "#6366f1" }}>{balVis ? fmtBRL(totals.gross) : "•••"}</td>
                <td className="px-4 py-3 text-sm font-bold font-mono-finance text-red-400">{balVis ? fmtBRL(totals.inss) : "•••"}</td>
                <td className="px-4 py-3 text-sm font-bold font-mono-finance text-amber-400">{balVis ? fmtBRL(totals.irrf) : "•••"}</td>
                <td className="px-4 py-3 text-sm font-bold font-mono-finance text-violet-400">{balVis ? fmtBRL(totals.fgts) : "•••"}</td>
                <td className="px-4 py-3" />
                <td className="px-4 py-3 text-sm font-bold font-mono-finance text-emerald-400">{balVis ? fmtBRL(totals.net) : "•••"}</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// ─── Settings View ────────────────────────────────────────────────────────────
function SettingsView({
  user, authToken, balVis, setBalVis, onUserUpdate,
}: {
  user: AuthUser;
  authToken: string;
  balVis: boolean;
  setBalVis: (v: boolean) => void;
  onUserUpdate: (u: AuthUser) => void;
}) {
  const { theme, toggleTheme } = useTheme();
  const [name, setName] = useState(user.name);
  const [curPw, setCurPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [confPw, setConfPw] = useState("");

    const updateProfileMut = trpc.localAuth.updateProfile.useMutation();
  const changePasswordMut = trpc.localAuth.changePassword.useMutation();

  const saveProfile = async () => {
    try {
      const updated = await updateProfileMut.mutateAsync({ userId: user.id, name });
      onUserUpdate(updated as AuthUser);
      localStorage.setItem("finopshub_user", JSON.stringify({ ...user, name: updated.name, avatar: updated.avatar }));
      toast.success("Perfil atualizado!");
    } catch (e: any) { toast.error(e.message || "Erro ao salvar"); }
  };
  const changePassword = async () => {
    if (newPw !== confPw) { toast.error("Senhas não coincidem"); return; }
    try {
      await changePasswordMut.mutateAsync({ userId: user.id, currentPassword: curPw, newPassword: newPw });
      toast.success("Senha alterada!");
      setCurPw(""); setNewPw(""); setConfPw("");
    } catch (e: any) { toast.error(e.message); }
  };

  const Section = ({ title, children }: { title: string; children: React.ReactNode }) => (
    <div className="glass-card p-5">
      <h3 className="text-sm font-bold mb-4" style={{ color: "rgba(255,255,255,0.7)" }}>{title}</h3>
      {children}
    </div>
  );

  return (
    <div className="space-y-4 max-w-2xl">
      <h2 className="text-lg font-bold" style={{ color: "rgba(255,255,255,0.9)" }}>Configurações</h2>

      <Section title="Perfil">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-16 h-16 rounded-full flex items-center justify-center text-xl font-bold text-white" style={{ background: "linear-gradient(135deg, #6366f1, #9945FF)" }}>
            {user.avatar}
          </div>
          <div>
            <p className="font-semibold" style={{ color: "rgba(255,255,255,0.9)" }}>{user.name}</p>
            <p className="text-sm" style={{ color: "rgba(255,255,255,0.4)" }}>{user.email}</p>
          </div>
        </div>
        <div className="space-y-3">
          <div>
            <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Nome</label>
            <input value={name} onChange={(e) => setName(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }} />
          </div>
          <div>
            <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>Email</label>
            <input value={user.email} disabled className="w-full px-3 py-2.5 rounded-xl text-sm opacity-50" style={{ background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.06)", color: "rgba(255,255,255,0.6)" }} />
          </div>
          <button onClick={saveProfile} className="px-4 py-2.5 rounded-xl text-sm font-semibold btn-primary-gradient">Salvar alterações</button>
        </div>
      </Section>

      {user.provider === "email" && (
        <Section title="Segurança">
          <div className="space-y-3">
            {[
              { label: "Senha atual", value: curPw, setter: setCurPw },
              { label: "Nova senha", value: newPw, setter: setNewPw },
              { label: "Confirmar nova senha", value: confPw, setter: setConfPw },
            ].map(({ label, value, setter }) => (
              <div key={label}>
                <label className="text-xs mb-1 block" style={{ color: "rgba(255,255,255,0.5)" }}>{label}</label>
                <input type="password" value={value} onChange={(e) => setter(e.target.value)} className="w-full px-3 py-2.5 rounded-xl text-sm" style={{ background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.9)" }} />
              </div>
            ))}
            <button onClick={changePassword} className="px-4 py-2.5 rounded-xl text-sm font-semibold btn-primary-gradient">Atualizar senha</button>
          </div>
        </Section>
      )}

      <Section title="Aparência">
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm" style={{ color: "rgba(255,255,255,0.7)" }}>Tema</span>
            <button onClick={toggleTheme} className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm" style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}>
              {theme === "dark" ? <><Sun size={14} /> Claro</> : <><Moon size={14} /> Escuro</>}
            </button>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm" style={{ color: "rgba(255,255,255,0.7)" }}>Ocultar valores</span>
            <button onClick={() => setBalVis(!balVis)} className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm" style={{ border: "1px solid rgba(255,255,255,0.1)", color: "rgba(255,255,255,0.6)" }}>
              {balVis ? <><Eye size={14} /> Visível</> : <><EyeOff size={14} /> Oculto</>}
            </button>
          </div>
        </div>
      </Section>

      <Section title="Sobre">
        <div className="space-y-2 text-sm">
          {[
            ["Versão", "FinOpsHub v1.0.0-mvp", "rgba(255,255,255,0.7)"],
            ["Rede", "Solana devnet", "#14F195"],
          ].map(([label, value, color]) => (
            <div key={label} className="flex justify-between">
              <span style={{ color: "rgba(255,255,255,0.5)" }}>{label}</span>
              <span className="font-mono-finance" style={{ color }}>{value}</span>
            </div>
          ))}
          <div className="flex justify-between">
            <span style={{ color: "rgba(255,255,255,0.5)" }}>Documentação</span>
            <a href="https://github.com" target="_blank" rel="noreferrer" className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1">
              GitHub <ExternalLink size={12} />
            </a>
          </div>
        </div>
      </Section>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function FinOpsHub() {
  const [authUser, setAuthUser] = useState<AuthUser | null>(null);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [mode, setMode] = useState<"financas" | "folha">("financas");
  const [view, setView] = useState("dashboard");
  const [balVis, setBalVis] = useState(true);

  const [accounts, setAccounts] = useState<Account[]>(INITIAL_ACCOUNTS);
  const [transactions, setTransactions] = useState<Transaction[]>(INITIAL_TRANSACTIONS);
  const [employees, setEmployees] = useState<Employee[]>(INITIAL_EMPLOYEES);
  const [batches, setBatches] = useState<PayrollBatch[]>(INITIAL_BATCHES);

  useEffect(() => {
    const token = localStorage.getItem("finopshub_token");
    const userStr = localStorage.getItem("finopshub_user");
    if (!token || !userStr) { setAuthLoading(false); return; }
    try {
      const user = JSON.parse(userStr);
      setAuthUser(user);
      setAuthToken(token);
    } catch {
      localStorage.removeItem("finopshub_token");
      localStorage.removeItem("finopshub_user");
    }
    setAuthLoading(false);
  }, []);

  const handleLogin = (user: AuthUser, token: string) => {
    setAuthUser(user);
    setAuthToken(token);
  };

  const handleLogout = () => {
    localStorage.removeItem("finopshub_token");
    localStorage.removeItem("finopshub_user");
    setAuthUser(null);
    setAuthToken(null);
  };

  const handleTransfer = (fromId: string, amount: number, dest: string) => {
    setAccounts((prev) => prev.map((a) => a.id === fromId ? { ...a, balance: a.balance - amount } : a));
    setTransactions((prev) => [{
      id: `t-${Date.now()}`,
      date: new Date(),
      desc: `Transferência para ${dest}`,
      amount,
      cat: "PIX",
      bankId: fromId,
      type: "expense" as const,
    }, ...prev]);
    toast.success(`${fmtBRL(amount)} transferido!`);
  };

  const handlePay = (fromId: string, amount: number, cat: string, desc: string) => {
    setAccounts((prev) => prev.map((a) => a.id === fromId ? { ...a, balance: a.balance - amount } : a));
    setTransactions((prev) => [{
      id: `t-${Date.now()}`,
      date: new Date(),
      desc,
      amount,
      cat,
      bankId: fromId,
      type: "expense" as const,
    }, ...prev]);
  };

  const handleDeposit = (toId: string, amount: number, desc: string) => {
    setAccounts((prev) => prev.map((a) => a.id === toId ? { ...a, balance: a.balance + amount } : a));
    setTransactions((prev) => [{
      id: `t-${Date.now()}`,
      date: new Date(),
      desc,
      amount,
      cat: "Renda",
      bankId: toId,
      type: "income" as const,
    }, ...prev]);
    toast.success(`${fmtBRL(amount)} depositado!`);
  };

  const handleImportCSV = (emps: Employee[], batch: PayrollBatch) => {
    setEmployees((prev) => [...prev, ...emps]);
    setBatches((prev) => [batch, ...prev]);
  };

  useEffect(() => {
    if (mode === "financas") setView("dashboard");
    else setView("payroll-dashboard");
  }, [mode]);

  if (authLoading) {
    return (
      <div className="app-bg min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 rounded-xl btn-primary-gradient flex items-center justify-center mx-auto mb-3">
            <span className="text-lg font-bold text-white">F</span>
          </div>
          <Loader2 size={20} className="animate-spin mx-auto" style={{ color: "#6366f1" }} />
        </div>
      </div>
    );
  }

  if (!authUser || !authToken) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  const renderView = () => {
    if (view === "settings") {
      return (
        <SettingsView
          user={authUser}
          authToken={authToken}
          balVis={balVis}
          setBalVis={setBalVis}
          onUserUpdate={(u) => setAuthUser(u)}
        />
      );
    }

    if (mode === "financas") {
      switch (view) {
        case "dashboard":
          return (
            <FinanceDashboard
              accounts={accounts}
              transactions={transactions}
              batches={batches}
              balVis={balVis}
              setView={setView}
              onTransfer={handleTransfer}
              onPay={handlePay}
              onDeposit={handleDeposit}
            />
          );
        case "contas":
          return <ContasView accounts={accounts} balVis={balVis} onTransfer={handleTransfer} />;
        case "extrato":
          return <ExtratoView transactions={transactions} accounts={accounts} balVis={balVis} />;
        case "cartoes":
          return <CartoesView balVis={balVis} setView={setView} />;
        case "crypto":
          return <CryptoView authToken={authToken} balVis={balVis} />;
        case "antecipar":
          return <AnteciparView authToken={authToken} />;
        default:
          return null;
      }
    } else {
      switch (view) {
        case "payroll-dashboard":
          return (
            <PayrollDashboard
              employees={employees}
              batches={batches}
              accounts={accounts}
              balVis={balVis}
              setBatches={setBatches}
              setAccounts={setAccounts}
              setTransactions={setTransactions}
            />
          );
        case "equipe":
          return <EquipeView employees={employees} balVis={balVis} />;
        case "importar":
          return <ImportarCSVView onImport={handleImportCSV} />;
        case "simulacao":
          return <SimulacaoView employees={employees} balVis={balVis} />;
        default:
          return null;
      }
    }
  };

  return (
    <div className="app-bg min-h-screen flex flex-col">
      <Header
        user={authUser}
        mode={mode}
        setMode={setMode}
        balVis={balVis}
        setBalVis={setBalVis}
        onLogout={handleLogout}
        onSettings={() => setView("settings")}
      />
      <div className="flex flex-1 overflow-hidden">
        {mode === "financas" && view !== "settings" ? (
          <FinanceSidebar view={view} setView={setView} />
        ) : mode === "folha" && view !== "settings" ? (
          <PayrollSidebar view={view} setView={setView} />
        ) : null}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6 pb-20 lg:pb-6">
          {renderView()}
        </main>
      </div>
      <MobileNav mode={mode} view={view} setView={setView} />
    </div>
  );
}
