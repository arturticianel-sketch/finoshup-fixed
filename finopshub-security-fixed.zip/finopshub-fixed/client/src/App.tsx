import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "./contexts/ThemeContext";
import FinOpsHub from "./pages/FinOpsHub";

function App() {
  return (
    <ThemeProvider defaultTheme="dark" switchable>
      <TooltipProvider>
        <Toaster position="bottom-center" richColors />
        <FinOpsHub />
      </TooltipProvider>
    </ThemeProvider>
  );
}

export default App;
