# FinOpsHub — TODO

## Core Infrastructure
- [x] Upgrade to web-db-user (tRPC + DB + Auth)
- [x] Database schema (users table)
- [x] tRPC routers: localAuth, wallet, card, defi
- [x] In-memory stores for wallet, card, NFe data

## Authentication
- [x] Login screen with email/password
- [x] Register screen
- [x] Google OAuth redirect (Manus OAuth)
- [x] Persistent auth via localStorage
- [x] Logout functionality

## Modo Finanças
- [x] Dashboard view with KPI cards
- [x] Area chart (saldo histórico)
- [x] Pie chart (categorias)
- [x] Contas view (bank accounts)
- [x] Extrato view (transaction list with filters)
- [x] Cartões view (credit cards)
- [x] Modal Pagar (PIX/TED/Boleto)
- [x] Modal Depositar
- [x] Modal Transferir

## Crypto / Solana View
- [x] Wallet connect (Phantom simulation)
- [x] Wallet create (devnet)
- [x] Airdrop SOL + USDC
- [x] Send SOL modal
- [x] Receive modal with QR code
- [x] Virtual card creation
- [x] Fund card with USDC
- [x] Toggle card status (block/unblock)
- [x] Simulate purchase
- [x] tRPC integration for all wallet/card operations

## Folha CLT
- [x] PayrollDashboard with stats
- [x] Equipe view (employee list)
- [x] Add/edit employee modal
- [x] CLT calculation engine (INSS, IRRF, FGTS)
- [x] Contracheque modal (pay stub)
- [x] Importar CSV view
- [x] Simulação view
- [x] Batch management (draft/calculated/paid)

## Antecipar (DeFi)
- [x] NFe list view
- [x] DeFi health status indicator
- [x] Simulate antecipação (tRPC)
- [x] Execute antecipação (tRPC)
- [x] Operações history
- [x] Quote modal with breakdown

## Settings
- [x] Profile update (tRPC)
- [x] Password change (tRPC)
- [x] Theme toggle (dark/light)
- [x] Balance visibility toggle

## Design
- [x] Glassmorphism Premium dark theme
- [x] DM Sans + DM Mono fonts
- [x] Cosmic gradient background
- [x] Glass cards with backdrop-blur
- [x] Indigo/violet accent colors
- [x] Responsive layout
- [x] Mode switcher (Finanças / Folha CLT)
- [x] Sidebar navigation

## Tests
- [x] Vitest: auth.logout test (existing)
- [x] Vitest: localAuth.login test
- [x] Vitest: wallet operations test
- [x] Vitest: defi simulation test
